﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class defines an enumerator called "Roles".  It holds all of the possible roles that a user could have.

namespace UserManagement.MVC.Enums
{
    //list of user roles
    public enum Roles
    {
        SuperAdmin,           //most privileged role, access to tools to manage roles
        Admin,                //administrative assistant, can enter no clinical notes
        Customer,             //can make, update, delete appts and pets (can enter no medical notes)
        VetTech,              //can enter/update appointment and most pet data, cannot enter/update doctor notes
        Vet                   //most privileged medical role, can make/edit/delete appts and pets, can add /edit doctor notes
    }
}

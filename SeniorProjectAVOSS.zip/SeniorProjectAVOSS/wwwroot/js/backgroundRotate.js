﻿/*
Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
CIS 4891
Group 1: Project
Apr. 17, 2022

Description: The JavaScript below provides the code for the carousel on the landing page. The carousel contains images of different animals to
showcase the range of animals that the vet office accepts as patients.

*/

/* images included */
var images = [
    "img/Backgrounds/Dog.jpg",
    "img/Backgrounds/Bird2.jpg",
    "img/Backgrounds/Lizard.jpg",
    "img/Backgrounds/Bird2.jpg",
    "img/Backgrounds/Bird3.jpg",
    "img/Backgrounds/Lizard3.jpg",
    "img/Backgrounds/Cat.jpg"
]

var imageHead = document.getElementById("image-head");

/* value for first image position */
var i = 0;

/* code for moving through the images */
setInterval(function () {
    imageHead.style.backgroundImage = "url(" + images[i] + ")";
    i = i + 1;
    if (i == images.length) {
        i = 0;
    }
    /* show each image for 4 seconds */
}, 4000);
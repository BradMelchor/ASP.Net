﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This model sets seed data for the database and sets up columns in the tables.

using Microsoft.AspNetCore.Identity;
using System.Linq;
using System.Threading.Tasks;
using UserManagement.MVC.Models;

namespace UserManagement.MVC.Data
{
    public static class ContextSeed
    {
        //seeds user roles
        public static async Task SeedRolesAsync(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            await roleManager.CreateAsync(new IdentityRole(Enums.Roles.VetTech.ToString()));     //vet tech role
            await roleManager.CreateAsync(new IdentityRole(Enums.Roles.Vet.ToString()));         //vet role
            await roleManager.CreateAsync(new IdentityRole(Enums.Roles.Customer.ToString()));    //customer role

        }
        //seed vet tech and vet
        public static async Task SeedSuperAdminAsync(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            var defaultVetOne = new ApplicationUser
            {
                UserName = "tiffanypeter",             //seed data for vet tech      
                Email = "peter@avoss.com",             //sets up columns for ApplicationUser table
                FirstName = "Tiffany",                 //columns include username, email, first and last names, emailed confirmed, phonenumberconfirmed, preferred vet, 
                LastName = "Peter",                    //preferred location, userrole
                EmailConfirmed = true,
                PhoneNumberConfirmed = true,
                PreferredVet = "Jones",
                PreferredLocation = "Millhopper",
                UserRole = "VetTech"
                
            };
            if (userManager.Users.All(u => u.Id != defaultVetOne.Id))                                   //if user is this seed user, credentials are as follows
            {
                var user = await userManager.FindByEmailAsync(defaultVetOne.Email);
                if (user == null)
                {
                    await userManager.CreateAsync(defaultVetOne, "Test1234!");                          //sets login password for seed user
                    await userManager.AddToRoleAsync(defaultVetOne, Enums.Roles.VetTech.ToString());
                }
            }

            var defaultVetTwo = new ApplicationUser
            {
                UserName = "gregstyles",                //seed data for vet
                Email = "styles@avoss.com",             //sets up columns for ApplicationUser table
                FirstName = "Greg",                     //columns include username, email, first and last names, emailed confirmed, phonenumberconfirmed, preferred vet,
                LastName = "Styles",                    //preferred location, userrole
                EmailConfirmed = true,
                PhoneNumberConfirmed = true,
                PreferredVet = "Styles",
                PreferredLocation = "Millhopper",
                UserRole = "Vet"

            };
            if (userManager.Users.All(u => u.Id != defaultVetTwo.Id))                                      //if user is this seed user, credentials are as follows
            {
                var user = await userManager.FindByEmailAsync(defaultVetTwo.Email);
                if (user == null)
                {
                    await userManager.CreateAsync(defaultVetTwo, "Test1234!");                             //sets login password for seed user
                    await userManager.AddToRoleAsync(defaultVetTwo, Enums.Roles.Vet.ToString());

                }

            }
        }
    }
}

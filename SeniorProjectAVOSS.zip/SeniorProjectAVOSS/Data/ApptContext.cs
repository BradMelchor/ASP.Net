//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This model sets up the ApptContext class to set up the database. In particular, it pulls together the different tables that are involved in making an appointment.  

using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using UserManagement.MVC.Models;

namespace ApptList.Models
{
    public class ApptContext : IdentityDbContext<ApplicationUser>          //ApptContext inherits from IdentityDbContext
    {
        public ApptContext(DbContextOptions<ApptContext> options)
            : base(options)
        { }

        public DbSet<Appt> Appts { get; set; }                             //gets/sets appts table
        public DbSet<Reason> Reasons { get; set; }                         //gets/sets reasons table
        public DbSet<Pet> Pets { get; set; }                               //gets/sets pet table
        public DbSet<ApplicationUser> ApplicationUsers { get; set; }       //gets/sets user table


        protected override void OnModelCreating(ModelBuilder modelBuilder)        //override for seed data in tables
        {
            base.OnModelCreating(modelBuilder);                            //required to link with AuthDB context file (for authorization)
        }
    }
}



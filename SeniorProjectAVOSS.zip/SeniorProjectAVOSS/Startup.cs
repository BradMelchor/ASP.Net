//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: The Startup file is the first file to execute upon starting AVOSS.  It sets up services that other classes will use such as session storage.
//The configure method holds middleware.

using ApptList.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using UserManagement.MVC.Data;
using UserManagement.MVC.Models;

namespace UserManagement.MVC
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        //holds services used by other classes
        public void ConfigureServices(IServiceCollection services)        
        {
            services.AddMemoryCache();                                              //enables session storage
            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromSeconds(60 * 5);                //time out after 5 min
                options.Cookie.HttpOnly = false;                                   //prevents some scripting attacks
            });

            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));      //connection string if one is not present
            services.AddIdentity<ApplicationUser, IdentityRole>()
                    .AddEntityFrameworkStores<ApplicationDbContext>()
                    .AddDefaultUI()
            .AddDefaultTokenProviders();
            services.AddControllersWithViews();
            services.AddRazorPages()                                          //enables razor pages
                .AddMvcOptions(options =>                                     //optimizes error msg for entered dates
                {
                    options.MaxModelValidationErrors = 50;
                    options.ModelBindingMessageProvider.SetValueMustNotBeNullAccessor(
                        _ => "Must add date.");
                });

            services.AddDbContext<ApptContext>(options =>
               options.UseSqlServer(Configuration.GetConnectionString("ApptContext")));        //gets connection string listed in json file and passes that to server
         

        }

        // sets up HTTP request pipeline
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //Code below allows as error message when server is not available.
            //This is only applicable when this application lives on a server.

            //**************************************************************
            // This should be stored as an ENV on the server running.
            // Comment out if not in MS visual studio env.
            // env.EnvironmentName = "Prod";
            //**************************************************************
            
            app.UseSession();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/error");
                app.UseHsts();                                  //default HSTS value = 30 days
            }
            app.UseHttpsRedirection();                          //enables program to send user to other pages
            app.UseStaticFiles();
            app.UseRouting();                                          
            app.UseAuthentication();                            //enables login
            app.UseAuthorization();                             //enables roles

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(                   //enables url customization
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}/{slug?}");
                endpoints.MapRazorPages();
            });
        }
    }
}

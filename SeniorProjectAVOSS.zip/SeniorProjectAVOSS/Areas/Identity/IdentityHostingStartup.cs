﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022


using Microsoft.AspNetCore.Hosting;


[assembly: HostingStartup(typeof(UserManagement.MVC.Areas.Identity.IdentityHostingStartup))]
namespace UserManagement.MVC.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
            });
        }
    }
}
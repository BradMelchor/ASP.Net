﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//This is for a future update, we can make it so if the user forgets their password they get an email, but email needs to be set up. This was part of the framework we used.

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace UserManagement.MVC.Areas.Identity.Pages.Account
{
    [AllowAnonymous]
    public class ForgotPasswordConfirmation : PageModel
    {
        public void OnGet()
        {
        }
    }
}

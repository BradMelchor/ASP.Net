﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Not used but here for future reference. This was part of the framework we used 

using Microsoft.AspNetCore.Mvc.RazorPages;

namespace UserManagement.MVC.Areas.Identity.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}


﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Model for the user.


using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using UserManagement.MVC.Models;

namespace UserManagement.MVC.Areas.Identity.Pages.Account.Manage
{
    public partial class IndexModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public IndexModel(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        //variables
        public string Username { get; set; }

        [TempData]
        public string StatusMessage { get; set; }
        [TempData]
        public string UserNameChangeLimitMessage { get; set; }

        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel
        {
        
            //regex for fist name and error message
            [Required(ErrorMessage = "A first name is required.")]
            [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿\\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,30}$", ErrorMessage = "No special characters allowed in last name. Must be 2-30 characters long.")]
            [Display(Name = "First Name")]

            public string FirstName { get; set; }
        
            //regex for last name and error message
            [Required(ErrorMessage = "A last name is required.")]
            [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿\\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,30}$", ErrorMessage = "No special characters allowed in last name. Must be 2-30 characters long.")]
            [Display(Name = "Last Name")]

            public string LastName { get; set; }

            //regex and error message for user name
            [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿\\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,30}$", ErrorMessage = "No special characters allowed in last name. Must be 2-30 characters long.")]
            public string Username { get; set; }


            //regex and error message for phone number
            [Required(ErrorMessage = "A phone number is required.")]
            [RegularExpression(@"^([2-9]\d{2}-\d{3}-\d{4})$", ErrorMessage = "Phone must be 10 digits with dashes (example: 352-222-2121). To be valid, cannot start with 0 or 1.")]
            [Display(Name = "Phone Number")]
            public string PhoneNumber { get; set; }

            //Profile picture is not used, but can be used in future update
            [Display(Name = "Profile Picture")]
            public byte[] ProfilePicture { get; set; }


            //Preferred location field
            [Required]
            [Display(Name = "Preferred Location")]
            public string PreferredLocation { get; set; }

            //preferred vet field
            [Required]
            [Display(Name = "Preferred Vet")]
            public string PreferredVet { get; set; }

            


        }

        private async Task LoadAsync(ApplicationUser user)
        {
            var userName = await _userManager.GetUserNameAsync(user);
            var phoneNumber = await _userManager.GetPhoneNumberAsync(user);
            var firstName = user.FirstName;
            var lastName = user.LastName;
            var profilePicture = user.ProfilePicture;
            var preferredVet = user.PreferredVet;
            var preferredLocation = user.PreferredLocation;


       
            Username = userName;

            Input = new InputModel
            {
                PhoneNumber = phoneNumber,
                Username = userName,
                FirstName = firstName,
                LastName = lastName,
                ProfilePicture = profilePicture,
                PreferredVet = preferredVet,
                PreferredLocation = preferredLocation
            };
        }

        public async Task<IActionResult> OnGetAsync()
        {
            //This will pass the Three Vets from the database into the dropdown
            var vetUsers = _userManager.Users
                .Where(s => s.UserRole == "Vet")
                .ToList();

            //Have to use ViewData in this instance
            ViewData["Vets"] = vetUsers;

            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }
            UserNameChangeLimitMessage = $"You can change your username {user.UsernameChangeLimit} more time(s).";
            await LoadAsync(user);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            if (!ModelState.IsValid)
            {
                await LoadAsync(user);
                return Page();
            }

            var phoneNumber = await _userManager.GetPhoneNumberAsync(user);
            if (Input.PhoneNumber != phoneNumber)
            {
                var setPhoneResult = await _userManager.SetPhoneNumberAsync(user, Input.PhoneNumber);
                if (!setPhoneResult.Succeeded)
                {
                    StatusMessage = "Unexpected error when trying to set phone number.";
                    return RedirectToPage();
                }
            }
            var firstName = user.FirstName;
            var lastName = user.LastName;
            var preferredVet = user.PreferredVet;
            var preferredLocation = user.PreferredLocation;

            //Adding code to capitilize first and last name
            System.Globalization.TextInfo textInfo = new System.Globalization.CultureInfo("en-US", false).TextInfo;
            string firstNameCap = textInfo.ToTitleCase(Input.FirstName);
            string lastNameCap = textInfo.ToTitleCase(Input.LastName);

            if (Input.FirstName != firstName)
            {

                user.FirstName = firstNameCap;
                await _userManager.UpdateAsync(user);
            }
            if (Input.LastName != lastName)
            {
                user.LastName = lastNameCap;
                await _userManager.UpdateAsync(user);
            }

            if (Input.PreferredLocation != preferredLocation)
            {
                user.PreferredLocation = Input.PreferredLocation;
                await _userManager.UpdateAsync(user);
            }

            if (Input.PreferredVet != preferredVet)
            {
                user.PreferredVet = Input.PreferredVet;
                await _userManager.UpdateAsync(user);
            }
            if (user.UsernameChangeLimit > 0)
            {
                if (Input.Username != user.UserName)
                {
                    var userNameExists = await _userManager.FindByNameAsync(Input.Username);
                    if (userNameExists != null)
                    {
                        StatusMessage = "User name already taken. Select a different username.";
                        return RedirectToPage();
                    }

                    var setUserName = await _userManager.SetUserNameAsync(user, Input.Username);
                    if (!setUserName.Succeeded)
                    {
                        StatusMessage = "User name is not allowed, please try a different one.";
                        return RedirectToPage();
                    }
                    else
                    {

                        //No change limit for AVOSS.
                        //user.UsernameChangeLimit -= 1;
                        await _userManager.UpdateAsync(user);
                    }
                }
            }

            if (Request.Form.Files.Count > 0)
            {
                IFormFile file = Request.Form.Files.FirstOrDefault();
                using (var dataStream = new MemoryStream())
                {
                    await file.CopyToAsync(dataStream);
                    user.ProfilePicture = dataStream.ToArray();
                }
                await _userManager.UpdateAsync(user);
            }
            await _signInManager.RefreshSignInAsync(user);
            StatusMessage = "Your profile has been updated";
            return RedirectToPage();
        }
    }
}

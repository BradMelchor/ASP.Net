﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This controller manages the actions involving the pet object.  From this controller, the application can add, edit, delete, or display details for each pet.
//The PetController class inherits properties from the controller class.

using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApptList.Models;
using System.Security.Claims;

namespace ApptList.Controllers
{
    public class PetController : Controller
    {
        //establishes context to manage pets
        private ApptContext context { get; set; }

        public PetController(ApptContext ctx)
        {
            context = ctx;
        }

        //add new pet object
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("EditPet", new Pet());
        }

        //change pet - first find pet in database with id
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Update";
            ViewBag.PetID = id;

            //find pet by id
            var pet = context.Pets.Find(id);

            //return data for that pet
            return View("EditPet", pet);
        }

        //edit or add pet object - accepts pet object
        [HttpPost]
        public IActionResult Edit(Pet pet)
        {
            context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;

            //if adding a new pet...
            if (pet.PetId == 0)
            {
                string key = nameof(Pet.PetName);
                string key2 = nameof(Pet.Species);

                //model-level validation (pet cannot be duplicated by user)
                if ((ModelState.GetValidationState(key) == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid) &&        
                    (ModelState.GetValidationState(key2) == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid)
                    )
                {
                    //get current user
                    ClaimsPrincipal currentUser = this.User;
                    var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;

                    //search to ensure customer is not entering same pet in system twice (check name, species, and userid)
                    Pet pet2 = context.Pets.Where(x => x.PetName == pet.PetName)
                               .Where(x => x.Species == pet.Species).Where(x => x.UserId == currentUserID).FirstOrDefault();
                              
                    //if there is no match, proceed to add pet
                    if (pet2 == null)
                    {
                        //nothing happens
                    }
                    
                    //user already added this pet, provide error message
                    else
                    {
                        ModelState.AddModelError(key2, "This pet already exists in the database.");
                    }
                }
            }

                //if model is valid...
                if (ModelState.IsValid)
                {

                //if adding a pet, set UserId of currently logged in user to UserId foreign key field
                if (pet.PetId == 0)
                {
                        ClaimsPrincipal currentUser = this.User;
                        var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;

                        pet.UserId = currentUserID;

                    //store proper case of user input
                    System.Globalization.TextInfo textInfo = new System.Globalization.CultureInfo("en-US", false).TextInfo;     
                        pet.PetName = textInfo.ToTitleCase(pet.PetName);
                        pet.SecondContactFst = textInfo.ToTitleCase(pet.SecondContactFst);
                        pet.SecondContactLst = textInfo.ToTitleCase(pet.SecondContactLst);

                    //add pet to database
                        context.Pets.Add(pet);

                    //save changes to database
                        context.SaveChanges();
                        
                    //return to user's homepage
                    return RedirectToAction("Index", "Home");
                }
                
                //updating pet
                else
                {
                    //if user updating pet is a customer, get userid from log in
                    if (User.IsInRole("Customer"))
                    {
                        ClaimsPrincipal currentUser = this.User;
                        var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;

                        pet.UserId = currentUserID;

                        //store proper case of user input (strings)
                        System.Globalization.TextInfo textInfo = new System.Globalization.CultureInfo("en-US", false).TextInfo;     
                        pet.PetName = textInfo.ToTitleCase(pet.PetName);
                        pet.SecondContactFst = textInfo.ToTitleCase(pet.SecondContactFst);
                        pet.SecondContactLst = textInfo.ToTitleCase(pet.SecondContactLst);

                        //update pet in database
                        context.Pets.Update(pet);

                        //save changes to database
                        context.SaveChanges();
                    }

                    //if user updating the pet is vet or vet tech, get userid tied to the specific pet (to know the pet's owner)
                    if (User.IsInRole("VetTech") || (User.IsInRole("Vet")))
                    {
                        //Search by PetName and Birthday in model.
                        var getUserId = context.Pets.Where(s => s.PetName == pet.PetName).Where(s=> s.Birthday == pet.Birthday).FirstOrDefault();
                        pet.UserId = getUserId.UserId;

                        //update pet in database
                        context.Pets.Update(pet);

                        //save changes to database
                        context.SaveChanges();
                    }

                    //return to user's homepage
                    return RedirectToAction("Index", "Home");
                }
            }

            //model failed with bad data - place user's entries into temp storage to prevent user from re-typing
            else           
            {         
                ViewBag.Action = (pet.PetId == 0) ? "Add" : "Edit";
                TempData["genderStore"] = $"{pet.Gender}";
                TempData["speciesStore"] = $"{pet.Species}";

                if (pet.Birthday.Year != 0001)
                {
                    string bday = pet.Birthday.ToString();
                    TempData["bdayStore"] = $"{bday}";
                }
                else
                {
                    pet.Birthday = DateTime.Now;
                    string date = pet.Birthday.ToShortDateString();
                    TempData["bdayStore"] = $"{date}";
                }

                //return to view with data, let user try again
                return View("EditPet", pet);
            }
        }


        //edit or add pet as employee
        [HttpPost]
        public IActionResult EditPetVetTech(Pet pet, string id)
        {
            context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            
            //if model is valid, proceed with processing
            if (ModelState.IsValid)
            {
                //if adding a pet, set UserId of the currently logged in user to the UserId foreign field
                if (pet.PetId == 0)
                {
                    ClaimsPrincipal currentUser = this.User;
                    var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;

                    pet.UserId = currentUserID;
                    context.Pets.Add(pet);

                    context.SaveChanges();
                    return RedirectToAction("Index", "Home");
                }
                
                //updating pet
                else
                {
                    //if user updating the pet is a customer, get userid from log in
                    if (User.IsInRole("Customer"))
                    {
                        ClaimsPrincipal currentUser = this.User;
                        var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;

                        pet.UserId = currentUserID;
                        
                        //update pet in database
                        context.Pets.Update(pet);

                        //save database changes
                        context.SaveChanges();
                    }

                    //if user upating the pet is vet or vettech, get the userid tied to the specific pet
                    if (User.IsInRole("VetTech") || (User.IsInRole("Vet")))
                    {
                        //search by PetName and Birthday in the model
                        var getUserId = context.Pets.Where(s => s.PetName == pet.PetName).Where(s => s.Birthday == pet.Birthday).FirstOrDefault();
                        pet.UserId = getUserId.UserId;

                        //pass in userid from view using asp-route
                        pet.UserId = id;

                        //update pet in database
                        context.Pets.Update(pet);

                        //save changes in database
                        context.SaveChanges();
                    }

                    //return to user's homepage
                    return RedirectToAction("Index", "Home");
                }

            }
            
            //model is not valid with bad data - place user's entries in temp storage to prevent user from re-typing
            else            
            {         
                ViewBag.Action = (pet.PetId == 0) ? "Add" : "Edit";
                TempData["genderStore"] = $"{pet.Gender}";
                TempData["speciesStore"] = $"{pet.Species}";

                if (pet.Birthday.Year != 0001)
                {
                    string bday = pet.Birthday.ToString();
                    TempData["bdayStore"] = $"{bday}";
                }
                else
                {
                    pet.Birthday = DateTime.Now;
                    string date = pet.Birthday.ToShortDateString();
                    TempData["bdayStore"] = $"{date}";
                }

                //return data to view, let user try again
                return View("EditPet", pet);
            }
        }

        //Delete pet - find pet to be deleted in database by id
        [HttpGet]
        public IActionResult Delete(int id)                   
        {
            //find pet by id
            var Pet = context.Pets.Find(id);
            
            //return pet's data to view
            return View(Pet);
        }

        //Delete pet - accepts pet object to be deleted
        [HttpPost]
        public IActionResult Delete(Pet Pet)          
        {
            //delete pet
            context.Pets.Remove(Pet); 
            
            //save changes to database
            context.SaveChanges();  
            
            //return to user's homepage
            return RedirectToAction("Index", "Home");          
        }

        //send pet details to screen
        [Route("home/index/details/pet-{id}/")]
        [HttpGet]
        public IActionResult Details(int id)                  
        {
            ViewBag.Action = "Pet Details";
            ViewBag.PetID = id;

            //find pet data based on pet's id
            var pet = context.Pets.Find(id);  
            
            //send pet's data to view
            return View(pet);                             
        }
    }
}


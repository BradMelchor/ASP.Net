﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This controller allows the vet tech to manage roles in AVOSS.  In particular, it enables the user to add a new
//role to the system if the vet office expands and needs a new role such as secretary.

using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace UserManagement.MVC.Controllers
{
    public class RoleManagerController : Controller
    {
        //get list of roles
        private readonly RoleManager<IdentityRole> _roleManager;
        
        //place into variable
        public RoleManagerController(RoleManager<IdentityRole> roleManager)
        {
            _roleManager = roleManager;
        }
       
        //send list of roles back to view
        public async Task<IActionResult> Index()
        {
            var roles = await _roleManager.Roles.ToListAsync();
            return View(roles);
        }
        
        //add role to database
        [HttpPost]
        public async Task<IActionResult> AddRole(string roleName)
        {
            
            //clean up user's data entry
            if (roleName != null)
            {
                await _roleManager.CreateAsync(new IdentityRole(roleName.Trim()));
            }
            
            //return to user's homepage
            return RedirectToAction("Index");
        }
    }
}
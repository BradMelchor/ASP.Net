﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This controller manages actions involving users, and it inherits from the standard controller class.
//In particular, the controller gets a user's details and passes them to a view where they can be reviewed and modified.

using Microsoft.AspNetCore.Mvc;
using ApptList.Models;

namespace ApptList.Controllers
{
    public class ApplicationUserController : Controller
    {
        private ApptContext context { get; set; }

        public ApplicationUserController(ApptContext ctx)
        {
            context = ctx;
        }

        //finds user's details and returns data to view
        [HttpGet]
        public IActionResult Details2(int id)                   //accepts user's id
        {
            ViewBag.Action = "User Details";
            ViewBag.UserID = id;

            var user = context.ApplicationUsers.Find(id);       //finds user based on id
            return View(user);                                  //return that user's data to view
        }
    }
}



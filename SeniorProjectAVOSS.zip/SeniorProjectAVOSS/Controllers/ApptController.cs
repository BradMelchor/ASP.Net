﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This controller manages the actions involving the appointment.  From this controller, the application can add, edit, delete, or display details for each appointment.
//The ApptController class inherits properties from the controller class.

using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using ApptList.Models;
using System.Collections.Generic;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using UserManagement.MVC.Models;
using Microsoft.EntityFrameworkCore;

namespace ApptList.Controllers
{
    public class ApptController : Controller
    {
        //Variable declarations
        private ApptContext context { get; set; }
        public static int petIdFinal = 99;
        private readonly UserManager<ApplicationUser> _userManager;
        public string custId = "";

        //establishes context to manage users
        public ApptController(ApptContext ctx, UserManager<ApplicationUser> userManager)
        {
            context = ctx;
            _userManager = userManager;
        }

        //adds new appointment object to database, accepts parameters from user
        [HttpGet]
        public IActionResult Add(string name, int petId, string firstName, string lastName, string petName, string site, string vet)                           
        {
            petIdFinal = petId;

            //collect data from context for displaying graphical view of appointemnts 
            var appt = context.Appts.Where(s => s.DateTime >= DateTime.Today).ToList();

            //pass the vets from database to dropdown menu
            ViewData.Clear();            
            var vetUsers = _userManager.Users
                .Where(s => s.UserRole == "Vet")
                .ToList();

            //clean data
            List<Object> cleanAppts = new List<Object>();
            foreach (Appt item in appt)
            {
                cleanAppts.Add(new 
                {
                    title = item.Vet,
                    start = item.DateTime,
                    end = item.EndDateTime
                });
            }

            //add appointments to view bag for processing
            ViewBag.cleanAppts = cleanAppts.ToList();

            //must use ViewData in this instance for temp storage
            ViewData["Vets"] = vetUsers.Distinct();

           //set ViewBag Action after the clear so it does not get cleared out
            ViewBag.Action = "Add";

            //set list view as default for next page
            TempData["TabV"] = "ListV";

            //pass in model values to be passed to appointment in edit view
            return View("Edit", new Appt { PrimaryFstName = firstName, PrimaryLstName = lastName, PetName = petName, Site = site, Vet = vet });                          
        } 

        //VetTech adds a new appointment to the system - data is slightly different for employees, so new method needed
        [HttpGet]
        public IActionResult VetTechAddAppointment(string Id, string firstName, string lastName, string vet, string site)
        {
            context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;

            //pass the vets from database into dropdown menu
            ViewData.Clear();            var vetUsers = _userManager.Users
                .Where(s => s.UserRole == "Vet")
                .ToList();
            
            //generate date for full calendar
            var appt = context.Appts.Where(s => s.DateTime >= DateTime.Today).ToList();
            
            //clean the data
            List<Object> cleanAppts = new List<Object>();
            foreach (Appt item in appt)
            {
                cleanAppts.Add(new
                {
                    title = item.Vet,
                    start = item.DateTime,
                    end = item.EndDateTime
                });
            }

            //add to view bag for processing
            ViewBag.cleanAppts = cleanAppts.ToList();

            //must use ViewData for temp storage to make it so vets appear in dropdown
            ViewData["Vets"] = vetUsers.Distinct();
            ViewBag.Action = "Add";

            //pass in list of Pets tied to specific customer needing appointment
            ViewBag.Pets = context.Pets.Where(s => s.UserId == Id).ToList();
            
            //set temp data for view
            TempData["Id"] = Id;
            var testc = TempData["Id"];
            TempData["TabV"] = "ListV";

            //pass in model values to be passed to appointment in VetTechEdit view
            return View("VetTechEdit", new Appt{ UserId = Id, PrimaryFstName = firstName, PrimaryLstName = lastName, Vet = vet, Site = site });
        }

        //manages edit action: gets appointment data from database before editing can occur
        [HttpGet]
        public IActionResult Edit(int id, int petId)                     
        {
            context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;

            petIdFinal = petId;

             //pass vets from database into dropdown menu
            ViewData.Clear();            
            var vetUsers = _userManager.Users
                .Where(s => s.UserRole == "Vet")
                .ToList();

            //must use ViewData for temp storage for dropdown on view
            ViewData["Vets"] = vetUsers.Distinct();

            ViewBag.Action = "Update";

            //get data for particular appointment that user wants to edit
            var appt = context.Appts.Find(id);    

            //collect data for displaying graphical view of appointemnts
            var currentAppointments = context.Appts.Where(s => s.DateTime >= DateTime.Today).ToList();

            //clean the data
            List<Object> cleanAppts = new List<Object>();
            foreach (Appt item in currentAppointments)
            {
                cleanAppts.Add(new
                {
                    title = item.Vet,
                    start = item.DateTime,
                    end = item.EndDateTime,   
                    });
                }

            //add to view bag for processing
            ViewBag.cleanAppts = cleanAppts.ToList();

            //if appointment is within 24 hours of now, give error message
            if (appt.DateTime - DateTime.Now <= TimeSpan.FromHours(24))
            {
                 return RedirectToAction("CancelWindow", "Appt");
            }
            else        //return specific appointment data to view for editing
            {
                TempData["TabV"] = "ListV";
                return View(appt);     
            }   
        }

        //posts appointment changes to database - accepts Appt object as parameter
        [HttpPost]
        public IActionResult Edit(Appt appt)                  
        {
            context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;

            //Clear ViewBag and ViewData to keep data clean
            ViewData.Clear();

            //pass vets from database into dropdown menu
            var vetUsers = _userManager.Users
                .Where(s => s.UserRole == "Vet")
                .ToList();

            //must use ViewData for temp storage for list of Vets and to make list view default
            ViewData["Vets"] = vetUsers;
            TempData["TabV"] = "ListV";
            
            //generate data for Full Calendar
            var currentAppointments = context.Appts.Where(s => s.DateTime >= DateTime.Today).ToList();

            //clean the data
            List<Object> cleanAppts = new List<Object>();
            foreach (Appt item in currentAppointments)
            {
                cleanAppts.Add(new
                {
                    title = item.Vet,
                    start = item.DateTime,
                    end = item.EndDateTime,
                });
            }

            //add to view bag for processing
            ViewBag.cleanAppts = cleanAppts.ToList();

            //if UserId is passed, set custId to appt.UserId to assign later
            if (appt.UserId != null)
            {
                custId = appt.UserId;
            }

            string key = nameof(Appt.Description);
            string key2 = nameof(Appt.DateTime);
     
            context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
           
            //calculate end time of changed appointment based on reason for visit
            if (appt.Description == "Annual Exam")                        
                appt.EndDateTime = appt.DateTime.AddMinutes(45);
            else if (appt.Description == "Vaccination")
                appt.EndDateTime = appt.DateTime.AddMinutes(30);
            else if (appt.Description == "Surgery")
                appt.EndDateTime = appt.DateTime.AddMinutes(180);
            else if (appt.Description == "Lab Analysis")
                appt.EndDateTime = appt.DateTime.AddMinutes(20);
            else if (appt.Description == "Blood Draw")
                appt.EndDateTime = appt.DateTime.AddMinutes(20);
            else if (appt.Description == "XRay")
                appt.EndDateTime = appt.DateTime.AddMinutes(30);
            else if (appt.Description == "Follow-Up")
                appt.EndDateTime = appt.DateTime.AddMinutes(20);
            else if (appt.Description == "Other")
                appt.EndDateTime = appt.DateTime.AddMinutes(40);
            else if (appt.Description == "Ear Infection")
                appt.EndDateTime = appt.DateTime.AddMinutes(25);

            //model-level validation (check that dates/times are appropriate)
            if ((ModelState.GetValidationState(key) == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid) &&       
                (ModelState.GetValidationState(key2) == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid))
            {
                //surgries are only on Friday at 8AM
                if ((appt.Description == "Surgery") && ((appt.DateTime.DayOfWeek != DayOfWeek.Friday) || (appt.DateTime.Hour != 8)))
                {
                    ModelState.AddModelError(key, "Surgeries can only be scheduled on Fridays at 8:00 AM.");
                }

                else
                {
                    //other than surgery, no other appt types can overlap with other appointments with same dr
                    if (appt.Description != "Surgery")                                  
                    {
                        //loop through all appointments and exclude current model for the time comparison to work
                        Appt appt2 = context.Appts.Where(x => x.EndDateTime > appt.DateTime)        //compares end times of other appts to start of this appt
                            .Where(x => x.Vet == appt.Vet)

                            //exclude current Appointment, compare to appoinments on same day only
                            .Where(x => x.ApptId != appt.ApptId)
                            .Where(x=> x.DateTime.Date == appt.DateTime.Date)
                            .FirstOrDefault();

                        Appt appt3 = context.Appts.Where(x => x.DateTime < appt.EndDateTime)         //compares start times of other appts to end of this appt
                           .Where(x => x.Vet == appt.Vet)

                           //exclude current Appointment, compare to appointments on same day only.
                            .Where(x => x.ApptId != appt.ApptId)
                            .Where(x=>x.DateTime.Date == appt.DateTime.Date)
                            .FirstOrDefault();

                        //if an appointment is found that overlaps with the proposed appointment, throw error
                        if ((appt2 != null) && (appt3 != null))
                        {
                            ModelState.AddModelError(key, "The vet does not have availability at this time.");
                        }
                    }
                } 
            }

            //if incoming data from model is valid...
            if (ModelState.IsValid)                           
            {
                context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
               
                //if ApptID = 0, it's a new appt (so add it as an object to database)
                if (appt.ApptId == 0)                        
                {
                    //vet tech is adding an appointment (petIdFinal is not set) - find petid to pass into model to keep data integrity
                    if (petIdFinal == 99 || User.IsInRole("Vet") || User.IsInRole("VetTech"))
                    {
                        var petId = context.Pets.Where(s => s.PetName == appt.PetName).FirstOrDefault();

                        var finalPetId = petId.PetId;
                        appt.PetId = finalPetId;
                        if (custId != "")
                        {
                            appt.UserId = custId;
                        }

                        //add appointment
                         context.Appts.Add(appt);

                    }

                    //customer is making an appointment
                    if (User.IsInRole("Customer"))
                    {
                        appt.PetId = petIdFinal;
                        ClaimsPrincipal currentUser = this.User;
                        var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;
                        appt.UserId = currentUserID;

                        //add appointment
                        context.Appts.Add(appt);
                    }
                }

                //update apptointment (id != 0)
                else
                {
                    //if user is a customer, update appointment with customer rules
                    if (User.IsInRole("Customer"))
                    {
                        appt.PetId = petIdFinal;
                        ClaimsPrincipal currentUser = this.User;
                        var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;
                        appt.UserId = currentUserID;

                        //update database
                        context.Appts.Update(appt);               
                    }

                    //if user is a VetTech, find the PetId and the UserId
                    //This requires more filtering because if there was double pet names/customers, AVOSS could update the incorrect one.
                    if  (User.IsInRole("VetTech") || User.IsInRole("Vet"))
                        {
                        //Find the pet via matching the PetName
                        var petIdTest = context.Pets.Where(s => s.PetName == appt.PetName).FirstOrDefault();
                        appt.PetId = petIdTest.PetId;

                        //Find user based on first and last name
                        var userIdSearch = _userManager.Users
                            .Where(s => s.FirstName == appt.PrimaryFstName && s.LastName == appt.PrimaryLstName).FirstOrDefault();
                         
                        appt.UserId = userIdSearch.Id;

                        //update database
                        context.Appts.Update(appt);
                    }
                }

                //save and return to home page
                context.SaveChanges();
                return RedirectToAction("Index", "Home");      
            }

            //data in object not valid
            else
            {                                                 
                //adding an appointment: add entered data to temp storage so user does not need to re-type entries
                if(appt.ApptId == 0)
                {
                    ViewBag.Action = "Add";
                    TempData["reasonStore"] = $"{appt.Description}";

                    if (appt.DateTime.Year != 0001)
                    {
                        string dt = appt.DateTime.ToString();
                        TempData["dateStore"] = $"{dt}";
                    }

                    else
                    {
                        appt.DateTime = DateTime.Now;
                        string dt = appt.DateTime.ToString();
                        TempData["dateStore"] = $"{dt}";
                    }

                    if (User.IsInRole("Customer"))
                        {
                        return View(appt);
                    }
                    else
                    {
                        TempData["petNameStore"] = $"{appt.Pet}";
                        
                        //return view with error message, let user try again
                        return View("VetTechEdit", appt);
                    }
                }

                //updating an appointment: add entered data to temp storage so user does not need to re-type entries
                else
                {
                    ViewBag.Action = "Update";
                    TempData["reasonStore"] = $"{appt.Description}";

                    if (appt.DateTime.Year != 0001)
                    {
                        string dt = appt.DateTime.ToString();
                        TempData["dateStore"] = $"{dt}";
                    }
                    else
                    {
                        appt.DateTime = DateTime.Now;
                        string dt = appt.DateTime.ToString();
                        TempData["dateStore"] = $"{dt}";
                    }

                    //return view with error message, let user try again
                    return View(appt);
                }
            }
        }

        //deletes appointment: first find appointment data in database
        [HttpGet]
        public IActionResult Delete(int id)                    
        {
            var appt = context.Appts.Find(id);

            //return appointment data to user
            return View(appt);
        }

        //deletes appointment: removes appointment from database
        [HttpPost]
        public IActionResult Delete(Appt appt)           
        {
                context.Appts.Remove(appt);                        //removal
                context.SaveChanges();                             //save
                return RedirectToAction("Index", "Home");          //return to home page
        }

        //provide error message if trying to change appt with less than 24 hours notice
        [Route("home/index/cancel_denied/")]
        [HttpGet]
        public IActionResult CancelWindow()                     
        { 
                return View();                            
        }

        //sets up homepage for customer
        [Route("home/index/customer_profile/")]
        [HttpGet]
        public IActionResult Profile()            
        {
            //log in stuff to compare userid of pet to userid of person logged in
            ClaimsPrincipal currentUser = this.User;
            var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;

            //Use routing to redirect - if null, redirect to home page
            //sets up appointments variable and places all rows in a list (ordered by date, then time)
            //filter by userId so customer can only see their own appointments
            ViewBag.Pets = context.Pets.Where(s => s.UserId == currentUserID ).ToList();
            var appts = context.Appts                   
                .Where(s => s.UserId == currentUserID)         
                .OrderBy(m => m.DateTime)
                .ToList();

            //return list of appointments to homepage
            return View(appts);                         
        }

        //return userObject so Vet or VetTech can view details of that user (email and phone)
        [HttpGet]
        public IActionResult UserDetails(string firstName, string lastName)                   
        {
            var userObject = _userManager.Users
                          .Where(s => s.FirstName == firstName && s.LastName == lastName).FirstOrDefault();

            return View(userObject);
        }

        //edit appointment made by vet or vet tech - data is slightly different, so new method required
        [HttpPost]
        public IActionResult EditVetTech(Appt appt, string userid)                  
        {
            context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;

            //clear ViewBag and ViewData to keep data clean
            ViewData.Clear();

            //pass Vets from database into dropdown menu
            var vetUsers = _userManager.Users
                .Where(s => s.UserRole == "Vet")
                .ToList();

            //use ViewData for temp storage for list of Vets, set list view as default
            ViewData["Vets"] = vetUsers;
            TempData["TabV"] = "ListV";

            //if UserId is passed, set custId to appt.UserId to assign later
            if (appt.UserId != null)
            {
                custId = appt.UserId;
            }

            string key = nameof(Appt.Description);
            string key2 = nameof(Appt.DateTime);

            //generate data for Full Calendar
            var currentAppointments = context.Appts.Where(s => s.DateTime >= DateTime.Today).ToList();

            //clean the data
            List<Object> cleanAppts = new List<Object>();
            foreach (Appt item in currentAppointments)
            {
                cleanAppts.Add(new
                {
                    title = item.Vet,
                    start = item.DateTime,
                    end = item.EndDateTime,
                });
            }

            //add to view bag for processing
            ViewBag.cleanAppts = cleanAppts.ToList();

            //determine/set appointment end time based on reason for appointment
            if (appt.Description == "Annual Exam")                        
                appt.EndDateTime = appt.DateTime.AddMinutes(45);
            else if (appt.Description == "Vaccination")
                appt.EndDateTime = appt.DateTime.AddMinutes(30);
            else if (appt.Description == "Surgery")
                appt.EndDateTime = appt.DateTime.AddMinutes(180);
            else if (appt.Description == "Lab Analysis")
                appt.EndDateTime = appt.DateTime.AddMinutes(20);
            else if (appt.Description == "Blood Draw")
                appt.EndDateTime = appt.DateTime.AddMinutes(20);
            else if (appt.Description == "XRay")
                appt.EndDateTime = appt.DateTime.AddMinutes(30);
            else if (appt.Description == "Follow-Up")
                appt.EndDateTime = appt.DateTime.AddMinutes(20);
            else if (appt.Description == "Other")
                appt.EndDateTime = appt.DateTime.AddMinutes(40);
            else if (appt.Description == "Ear Infection")
                appt.EndDateTime = appt.DateTime.AddMinutes(25);

            //model-level validation
            if ((ModelState.GetValidationState(key) == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid) &&        
                (ModelState.GetValidationState(key2) == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid))
            {
                //ensure that surgeries are only scheduled for Friday at 8AM
                if ((appt.Description == "Surgery") && ((appt.DateTime.DayOfWeek != DayOfWeek.Friday) || (appt.DateTime.Hour != 8)))
                {
                    ModelState.AddModelError(key, "Surgeries can only be scheduled on Fridays at 8:00 AM.");
                }

                else
                {
                    //other than surgery, no other appointment types can overlap with same doctor
                    if (appt.Description != "Surgery")                                  
                    {
                        //Need to loop through all appointments and exclude current model for the time comparison to work
                        Appt appt2 = context.Appts.Where(x => x.EndDateTime > appt.DateTime)
                            .Where(x => x.Vet == appt.Vet)

                            //Do not want to search the current Appointment, so want to compare to same day appoinments only.
                            .Where(x => x.ApptId != appt.ApptId)
                            .Where(x => x.DateTime.Date == appt.DateTime.Date)

                            .FirstOrDefault();

                        Appt appt3 = context.Appts.Where(x => x.DateTime < appt.EndDateTime)
                           .Where(x => x.Vet == appt.Vet)

                            //Do not want to search the current appointment, do want to compare to same day appointments only.
                            .Where(x => x.ApptId != appt.ApptId)
                            .Where(x => x.DateTime.Date == appt.DateTime.Date)

                           .FirstOrDefault();

                        if ((appt2 != null) && (appt3 != null))

                        {
                            ModelState.AddModelError(key, "The vet does not have availability at this time.");
                        }
                    }
                }

            }

            //if incoming data from model is valid...
            if (ModelState.IsValid)
            {
                //if ApptID = 0, it's a new appt (so add it as an object to database)
                if (appt.ApptId == 0)
                {
                    //vet tech is adding appointment (petIdFinal is not set) - find petid to pass into model to keep data integrity
                    if (petIdFinal == 99)
                    {
                        var petId = context.Pets.Where(s => s.PetName == appt.PetName).FirstOrDefault();

                        var finalPetId = petId.PetId;
                        appt.PetId = finalPetId;
                        if (custId != "")
                        {
                            appt.UserId = custId;
                        }

                        //add appointment to database
                        context.Appts.Add(appt);
                    }

                    //customer makes appointment
                    else
                    {
                        appt.PetId = petIdFinal;
                        ClaimsPrincipal currentUser = this.User;
                        var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;
                        appt.UserId = currentUserID;
                        
                        //add appointment to database
                        context.Appts.Add(appt);
                    }
                }

                //update appointment (id != 0)
                else
                {
                    //if user is a customer, update appointment based on customer rules
                    if (User.IsInRole("Customer"))
                    {
                        appt.PetId = petIdFinal;
                        ClaimsPrincipal currentUser = this.User;
                        var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;
                        appt.UserId = currentUserID;

                        //update appointment
                        context.Appts.Update(appt);
                    }

                    //if user is a VetTech, find PetId and UserId
                    //This requires more filtering because if there were double pet names/customers, AVOSS could update the incorrect one.
                    if (User.IsInRole("VetTech") || User.IsInRole("Vet"))
                    {
                        //Find pet via matching the PetName
                        var petIdTest = context.Pets.Where(s => s.PetName == appt.PetName).FirstOrDefault();
                        appt.PetId = petIdTest.PetId;

                        //Make equal to variable at the top
                        appt.UserId = userid;

                        //update appointment
                        context.Appts.Update(appt);
                    }
                }

                //save changes and return to homepage
                context.SaveChanges();
                return RedirectToAction("Index", "Home");     
            }

            //data in object not valid
            else
            {                                                 
                //adding appointment - place data entered by user into temp storage to prevent user from re-typing
                if (appt.ApptId == 0)
                {
                    ViewBag.Action = "Add";
                    TempData["reasonStore"] = $"{appt.Description}";

                    if (appt.DateTime.Year != 0001)
                    {
                        string dt = appt.DateTime.ToString();
                        TempData["dateStore"] = $"{dt}";
                    }
                    else
                    {
                        appt.DateTime = DateTime.Now;
                        string dt = appt.DateTime.ToString();
                        TempData["dateStore"] = $"{dt}";
                    }

                    //return data with error message, let user try again
                    return View(appt);
                }
                
                //updating appointment - place data entered by user into temp storage to prevent user from re-typing
                else
                {
                    ViewBag.Action = "Update";
                    TempData["reasonStore"] = $"{appt.Description}";
                    TempData["petStore"] = $"{appt.PetName}";

                    if (appt.DateTime.Year != 0001)
                    {
                        string dt = appt.DateTime.ToString();
                        TempData["dateStore"] = $"{dt}";
                    }
                    else
                    {
                        appt.DateTime = DateTime.Now;
                        string dt = appt.DateTime.ToString();
                        TempData["dateStore"] = $"{dt}";
                    }

                    //return data with error message, let user try again
                    return View("Edit", appt);
                }
            }
        }
    }
}
﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This controller manages the homepage actions for the different types of users.  From the landing page, users can request to go other pages.
//Those requests come through this controller, which returns the requested view.

using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using UserManagement.MVC.Models;

namespace UserManagement.MVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
    
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        //after logging in, re-route user to correct homepage
        public IActionResult Index()
        {
            //if user has successfully logged in...
            if (User.Identity.IsAuthenticated)
            {
                //if user is customer, route to customer homepage
                if (User.IsInRole("Customer"))
                {
                    TempData["TabV"] = "ListV";
                    ViewBag.Role = "cust";
                    return RedirectToAction("Profile", "Appt");
                }

                //if user is vet, route to employee page
                else if (User.IsInRole("Vet"))
                {
                    TempData["TabV"] = "ListV";
                    return RedirectToAction("Index", "ApptHomePage");
                }

                //if user is vet tech, route to employee page
                else if (User.IsInRole("VetTech"))
                {
                    TempData["TabV"] = "ListV";
                    return RedirectToAction("Index", "ApptHomePage");
                }

                //if user is not customer, vet, or vet tech, return landing page
                else
                    return View();
            }
            
            //user not logged in - return landing page
            else
                return View();
        }

        //return about page
        public ActionResult About()
        {
            return View("About");
        }

        //return help page
        public IActionResult Help()
        {
            return View("Help");
        }

        //provide error message when pages are not available
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

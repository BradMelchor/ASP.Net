﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This controller was automatically generated when ASP.NET MVC Core created the project. When all configurations are set,
//the controller manages actions involving error messages.

using Microsoft.AspNetCore.Mvc;

namespace SeniorProjectAVOSS.Controllers
{
    public class ErrorController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

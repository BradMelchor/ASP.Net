﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This controller provides the data for the homepage for the vet and vet techs.  Since these employees require the ability to filter and sort long lists
//of appointments, this controller enables the filtering and sorting actions.

using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApptList.Models;
using System;
using Microsoft.AspNetCore.Http;
using UserManagement.MVC.Models;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Security.Claims;

namespace ApptList.Controllers
{
    public class ApptHomePageController : Controller
    {
        private ApptContext context { get; set; }
        private readonly UserManager<ApplicationUser> _userManager;

        public ApptHomePageController(ApptContext ctx, UserManager<ApplicationUser> userManager)
        {
            context = ctx;
            _userManager = userManager;
        }

        //controls index action - accepts filter and sort values 
        public IActionResult Index(string sortOrder, string vetFilter, string siteFilter, string dateFilter, string ascDesc, string currentSortOrder)                    
        {
            //set list view as default view
            TempData["TabV"] = "ListV";

            //pass Vets from database into dropdown menu
            ViewData.Clear();            
            var vetUsers = _userManager.Users
                .Where(s => s.UserRole == "Vet")
                .ToList();

            //use ViewData for temp storage to show vets
            ViewData["Vets"] = vetUsers.Distinct();

            //get list of customers for dropdown menu
            var customerUsers = _userManager.Users
                .Where(s => s.UserRole == "Customer")
                .ToList();

            ViewBag.Customers = customerUsers;
         
            //store Appts 
            var appts = context.Appts.AsNoTracking().AsQueryable();
            
            //get today's date for date filter
            var today = DateTime.Now.ToString("M/dd/yyyy");

            //if user is vet vech, filter will show all vets, so the vetFilter is not set
            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole("VetTech"))
                {
                    if (String.IsNullOrEmpty(vetFilter)) vetFilter = "0";
                }

                //if user is vet, find last name of the vet logged in and use that as value of vet filter
                if (User.IsInRole("Vet"))
                {
                    //get the last name of the currently logged in vet
                    ClaimsPrincipal currentUser = this.User;
                    var currentUserID = currentUser.FindFirst(ClaimTypes.NameIdentifier).Value;

                    //search the object
                    var vetObject = _userManager.Users
                        .Where(s => s.Id == currentUserID).FirstOrDefault();

                    //get the last name of the vet signed in
                    var vetLoggedIn = vetObject.LastName;

                    //set the filter to the currently logged in vet's last name
                    if (String.IsNullOrEmpty(vetFilter)) vetFilter = vetLoggedIn;  
                }
            }
            
            //set defaults for filter and sort values
            if (String.IsNullOrEmpty(siteFilter)) siteFilter = "0";
            if (String.IsNullOrEmpty(dateFilter)) dateFilter = "0";
            if (String.IsNullOrEmpty(ascDesc)) ascDesc = "asc";
            if (String.IsNullOrEmpty(sortOrder)) sortOrder = "Date";
            
            //reverse sort if the same sortOrder is submitted a second time
            if (currentSortOrder == sortOrder)
            {
               ascDesc =  ascDesc == "asc" ? "desc" : "asc";
            }

            //update the session (filter and sort data)
            HttpContext.Session.SetString("vetStore", vetFilter);
            HttpContext.Session.SetString("siteStore", siteFilter);
            HttpContext.Session.SetString("dateStore", dateFilter);
            HttpContext.Session.SetString("currentSortOrder", sortOrder );
            HttpContext.Session.SetString("ascDesc", ascDesc );

            //filter for date
            if (dateFilter != "0") appts = appts.Where(a => a.DateTime > DateTime.Today).Where(a => a.DateTime < DateTime.Today.AddDays(1));

            //filter by vet
            if (vetFilter != "0") appts = appts.Where(s => s.Vet == vetFilter);

            //filter by site
            if (siteFilter != "0") appts = appts.Where(s => s.Site == siteFilter);

            //set sort order and sort by desc or asc
            switch (sortOrder)
            {
                case "Site":
                    if (ascDesc == "asc")
                    {
                        appts = appts
                            .OrderBy(s => s.Site)
                            .ThenBy(s => s.DateTime);
                    }
                    else
                    {
                        appts = appts
                            .OrderByDescending(s => s.Site)
                            .ThenBy(s => s.DateTime);
                    }
                    break;

                case "Vet":
                    if (ascDesc == "asc")
                    {
                        appts = appts
                        .OrderBy(s => s.Vet)
                        .ThenBy(s => s.DateTime);
                    }
                    else
                    {
                        appts = appts
                        .OrderByDescending(s => s.Vet)
                        .ThenBy(s => s.DateTime);
                    }
                    break;

                case "Reason":
                    if (ascDesc == "asc")
                    {
                        appts = appts
                        .OrderBy(s => s.Description)
                        .ThenBy(s => s.DateTime);
                    }
                    else
                    {
                        appts = appts
                        .OrderByDescending(s => s.Description)
                        .ThenBy(s => s.DateTime);
                    }
                    break;

                case "PetName":
                    if (ascDesc == "asc")
                    {
                        appts = appts
                        .OrderBy(s => s.PetName)
                        .ThenBy(s => s.DateTime);
                    }
                    else
                    {
                        appts = appts
                        .OrderByDescending(s => s.PetName)
                        .ThenBy(s => s.DateTime);
                    }
                    break;

                case "Owner":
                    if (ascDesc == "asc")
                    {
                        appts = appts
                        .OrderBy(s => s.PrimaryFstName)
                        .ThenBy(s => s.DateTime);
                    }
                    else
                    {
                        appts = appts
                        .OrderByDescending(s => s.PrimaryFstName)
                        .ThenBy(s => s.DateTime);
                    }
                    break;

                case "Date":
                    if (ascDesc == "asc")
                    {
                        appts = appts.OrderBy(s => s.DateTime);
                    }
                    else
                    {
                        appts = appts.OrderByDescending(s => s.DateTime);
                   }
                break;

                default:
                    appts = appts.OrderBy(s => s.DateTime);
                    break;
            }

            //return list of appointments to homepage
            var results = appts.ToList();
            return View(results);                         
        }
    }
}

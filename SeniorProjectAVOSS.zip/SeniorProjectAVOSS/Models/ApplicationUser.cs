﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class holds data for the application user.  It contains data such as the user's name and basic information about that user's pet.

using ApptList.Models;
using Microsoft.AspNetCore.Identity;


namespace UserManagement.MVC.Models
{
    public class ApplicationUser : IdentityUser
    {
        //user's first name
        public string FirstName { get; set; }

        //user's last name
        public string LastName { get; set; }

        //used to limit number of times user can change passwords over a period of time
        public int UsernameChangeLimit { get; set; } = 10;

        //directs program to user's profile image
        public byte[] ProfilePicture { get; set; }

        //user's pet object
        public Pet Pet { get; set; }

        //id of user's pet
        public int? PetId { get; set; }

        //primary key to identify user
        public int UserId { get; set;}

        //user's role
        public string UserRole { get; set; }

        //user's preferred location for appointments
        public string PreferredLocation { get; set; }

        //user's preferred vet for appointments
        public string PreferredVet { get; set; }

        //Phone number is stored at the base identity level 

    }

}

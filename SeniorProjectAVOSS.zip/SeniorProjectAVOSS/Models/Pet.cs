﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: The pet class contains data concerning each pet.  The class holds demographic data such as the name, age, weight, and species of the animal.  It
//also holds medical data entered and updated by the medical team.

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace ApptList.Models
{
    public class Pet
    {
        //numerical primary key with value automatically set by EF Core
        public int PetId { get; set; }

        //numerical foreign key to link with pet with owner
        [MaxLength(128), ForeignKey("ApplicationUser")]
        public virtual string UserId { get; set; }

        //name of pet
        [Required (ErrorMessage = "A pet name is required.")]
        [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿\\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,30}$", ErrorMessage = "No special characters allowed in pet name. Must be 2-30 characters long.")]
        public string PetName { get; set; }

        //pet's birthday - used to automatically calculate age of pet
        [Required(ErrorMessage = "A birthday is required to determine age of pet.")]
        [AVOSS.Models.BDayRange]
        public DateTime Birthday { get; set; }

        //pet's species
        [Required(ErrorMessage = "Species is required.")]
        public string Species { get; set; }

        //weight of pet (in pounds)
        [Required(ErrorMessage = "Weight is required.")]
        [Range(1,200, ErrorMessage = "Pet's weight must be between 1 and 200 pounds.")]
        public int? Weight { get; set; }

        //vaccines pet received
        [RegularExpression(@"^([a-zA-Z \-]{0,200})$", ErrorMessage = "No special characters allowed in vaccines. Limit of 200 characters.")]
        public string Vaccines { get; set; }

        //medications pet currently takes
        [RegularExpression(@"^([a-zA-Z0-9 \.\-]{0,200})$", ErrorMessage = "No special characters allowed in active medications. Limit of 200 characters.")]
        public string ActiveMedications { get; set; }

        //recent medical problems
        [RegularExpression(@"^([a-zA-Z0-9 \.\-]{0,200})$", ErrorMessage = "No special characters allowed in issues. Limit of 200 characters.")]
        public string Issues { get; set; }

        //chronic medical problems
        [RegularExpression(@"^([a-zA-Z0-9 \.\-]{0,200})$", ErrorMessage = "No special characters allowed in ongoing issues. Limit of 200 characters,")]
        public string OngoingIssues { get; set; }

        //entry and edits restricted to doctor - used for medical diagnoses and other technical data
        [RegularExpression(@"^([a-zA-Z0-9 \.\-]{0,200})$", ErrorMessage = "No special characters allowed in doctor notes. Limit of 200 characters.")]
        public string DoctorNotes { get; set; }

        //pet's gender
        [Required(ErrorMessage = "Gender is required.")]
        public string Gender { get; set; }

        //first name of alternate contact
        [Required(ErrorMessage = "A first name for the second contact is required.")]
        [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿\\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,30}$", ErrorMessage = "No special characters allowed in last name. Must be 2-30 characters long.")]
        public string SecondContactFst { get; set; }

        //last name of alternate contact
        [Required(ErrorMessage = "A last name for the second contact is required.")]
        [RegularExpression(@"^[\w'\-,.][^0-9_!¡?÷?¿\\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,30}$", ErrorMessage = "No special characters allowed in last name. Must be 2-30 characters long.")]
        public string SecondContactLst { get; set; }

        //phone number of alternate contact
        [Required(ErrorMessage = "A phone number for the second contact is required.")]
        [RegularExpression(@"^([2-9]\d{2}-\d{3}-\d{4})$", ErrorMessage = "Phone must be 10 digits with dashes (example: 352-222-2121). To be valid, cannot start with 0 or 1.")]
        public string SecondContactPh { get; set; }

    }
}

﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class stores data about custom roles, which allows vet technicians to enter new roles in the database as the business expands.

using System.ComponentModel.DataAnnotations;


namespace UserManagement.MVC.Models
{
    public class ManageUserRolesViewModel
    {
        public string RoleId { get; set; }                //numerical id for new role

        [RegularExpression(@"^[^/\\()~!@#$%^&*]*$", ErrorMessage = "No special characters allowed in Role Name.")]
        public string RoleName { get; set; }              //name of new role

        public bool Selected { get; set; }                //indicates whether user selected this role for another user
    }
}

﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class is used to validate the pet's birthday. The class prevents birthdays that are in the future or over 30 years ago.
//If the class indicates a failed attempt, it returns an appropriate error message.

using System;
using System.ComponentModel.DataAnnotations;

namespace AVOSS.Models
{
    public class BDayRange : ValidationAttribute
    {
        //determines if user's entry for pet's birthday is valid
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime bday = Convert.ToDateTime(value);           //converts parameter value to datetime

            if ((bday >= DateTime.Now) || (bday < DateTime.Now.AddYears(-30)))         //compares value to unacceptable ranges
            {
                return new ValidationResult("Birthday can't be after today or before 30 years before today.");          //error message if data is bad
            }
            else
            {
                return ValidationResult.Success;
            }
        }
    }
}

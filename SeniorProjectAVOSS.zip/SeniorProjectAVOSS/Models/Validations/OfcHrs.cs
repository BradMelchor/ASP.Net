﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class is used to validate the time of the appointment. The class prevents appointments from being scheduled before 8AM or after 4PM (must be within office hours).
//If the class indicates a failed attempt, it returns an appropriate error message.

using System;
using System.ComponentModel.DataAnnotations;

namespace AVOSS.Models
{
    public class OfcHrs : ValidationAttribute
    {
        //determines if user's entry for appointment time is valid
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime dateAppt = Convert.ToDateTime(value);                //converts parameter value to datetime

            if ((dateAppt.Hour < 8) || (dateAppt.Hour > 16))              //compares value to unacceptable time
            {
                return new ValidationResult("No appointments are accepted before 8AM or after 4PM.");         //error message if data is bad
            }
            else
            {
                return ValidationResult.Success;
            }
        }

    }
}

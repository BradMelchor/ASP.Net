﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class is used to validate the date of the appointment. The class prevents appointments from being scheduled more than six months from now.
//If the class indicates a failed attempt, it returns an appropriate error message.

using System;
using System.ComponentModel.DataAnnotations;

namespace AVOSS.Models
{
    public class Future : ValidationAttribute
    {
        //determines if user's entry for appointment date is valid
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime dateAppt = Convert.ToDateTime(value);               //converts parameter value to datetime

            if (dateAppt < DateTime.Now.AddMonths(6))                    //compares value to acceptable date and time
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("Appointment date can't be more than 6 months from now.");        //error message if data is bad
            }
        }

    }
}

﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class is used to validate the date of the appointment. The class prevents appointments from being scheduled as a same-day appointment if the
//user is a customer. The class enables vets and vet technicians to make same-day appointments on behalf of customers. If the class indicates a failed attempt,
//it returns an appropriate error message.

using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace AVOSS.Models
{
 
    public class SameDay : ValidationAttribute
    {
        //determines if user's entry for appointment date is valid
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime dateAppt = Convert.ToDateTime(value);                         //converts parameter value to datetime

            var httpContextAccessor = (IHttpContextAccessor)validationContext.GetService(typeof(IHttpContextAccessor));       //find current user (this line and next)
            var user = httpContextAccessor.HttpContext.User;

            if (user.IsInRole("Customer"))                                         //if user is customer, ensure it's not a same-day appointment
            {
                if (dateAppt.ToShortDateString() == DateTime.Now.ToShortDateString())             //compares value to unacceptable date and time
                {
                    return new ValidationResult("Please call the office for same-day appointments.");       //error message if data is bad
                }
                else
                {
                    return ValidationResult.Success;
                }
            }

            else                                                                   //user is not customer, so no need to validate for same-day
            {
                return ValidationResult.Success;
            }
            
        }
    }
}

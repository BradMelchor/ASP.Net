﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class is used to validate the date of the appointment. The class prevents appointments from being scheduled in the past.
//If the class indicates a failed attempt, it returns an appropriate error message.

using System;
using System.ComponentModel.DataAnnotations;


namespace AVOSS.Models
{
       public class DateRange : ValidationAttribute
    {
        //determines if user's entry for appointment date is valid
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime dateAppt = Convert.ToDateTime(value);            //converts parameter value to datetime

            if (dateAppt < DateTime.Now)                              //compares value to unacceptable date and time
            {
                    return new ValidationResult("Appointment date can't be in the past.");      //error message if data is bad
            }
                else
                {
                    return ValidationResult.Success;
                }
        }

    }
}

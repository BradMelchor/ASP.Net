﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class is used to validate the date of the appointment. The class prevents appointments from being scheduled on certain holidays.
//If the class indicates a failed attempt, it returns an appropriate error message.

using System;
using System.ComponentModel.DataAnnotations;

namespace AVOSS.Models
{
    public class Holidays : ValidationAttribute
    {
        //determines if user's entry for appointment date is valid
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime dateAppt = Convert.ToDateTime(value);                      //converts parameter value to datetime

            if (((dateAppt.Month == 12) && (dateAppt.Day == 24)) || ((dateAppt.Month == 12) && (dateAppt.Day == 25)) || ((dateAppt.Month == 1) && (dateAppt.Day == 1)) 
                || ((dateAppt.Month == 7) && (dateAppt.Day == 4)))              //compares value to unacceptable dates
            {
                return new ValidationResult("No appointments are accepted on the following holidays: Dec. 24, Dec. 25, Jan 1, Jul 4.");     //error message if data is bad
            }
            else
            {
                return ValidationResult.Success;
            }
        }

    }
}

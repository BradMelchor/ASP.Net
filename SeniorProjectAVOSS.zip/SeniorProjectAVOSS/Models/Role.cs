﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class contains data about each user role.


namespace ApptList.Models
{
    public class Role
    {
        public int RoleId { get; set; }           //numerical identification for role

        public string RoleName { get; set; }      //role    

    }
}

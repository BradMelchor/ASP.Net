//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: The class is automatically provided when ASP.NET MVC Core builds a new project.  As a view model, it enables error messages to more easily
//appear in views with this model passing only the data needed for the view.

namespace UserManagement.MVC.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }                               //identifies error with description

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);      //indicates if error message should be shown
    }
}

﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This model allows more than one model to converge into one unit that can more easily feed a view as one entity.  In this case, the 
//model is combining fields from the user and role models.

using System.Collections.Generic;

namespace UserManagement.MVC.Models
{
    public class UserRolesViewModel
    {
        public string UserId { get; set; }              //user model - id of user
        public string FirstName { get; set; }           //user model - name of user
        public string LastName { get; set; }            //user model - name of user
        public string UserName { get; set; }            //user model - username of user
        public string Email { get; set; }               //user model - email of user
        public IEnumerable<string> Roles { get; set; }    //role model - list of roles 
    }
}

﻿//Christie McLaughlin, Kate Blunt, David McDonald, Bradley Melchor
//CIS 4891
//Group 1: Project
//Apr. 17, 2022

//Description: This class contains data about each possible reason a user could have for scheduling an appointment.  This is used to determine the amount of time 
//the appointment will require.  With that data, the program can calculate the end time of the appointment.

namespace ApptList.Models
{
    public class Reason
    {
        public int ReasonId { get; set; }           //reason for visit: numerical code for reason
        public string Description { get; set; }     //reason for visit
        public int Time { get; set; }               //length of time needed in minutes

    }
}

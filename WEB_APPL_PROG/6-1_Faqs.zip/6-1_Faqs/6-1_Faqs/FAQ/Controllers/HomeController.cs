﻿//Brad Melchor
//COP4813.0m1
//10.6.20
//FAQ
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FAQ.Models;
using Microsoft.EntityFrameworkCore;

namespace FAQ.Controllers
{

    public class HomeController : Controller
    {
        private FAQContext context { get; set; }
        public HomeController(FAQContext ctx)
        {
            context = ctx;
        }
        //routes to index using /
        [Route("/")]
        public IActionResult Index()
        {
            var FAQ = context.FAQs.Include(c => c.Category).Include(t => t.Topic).OrderBy(f => f.FAQName).ToList();
            return View(FAQ);
        }
        //topic action that accepts topicID and Category ID and filters it based on Category ID
        [Route("/[controller]/index/[action]/{TopicID?}/category/{CategoryId?}")]
        public IActionResult topic(String TopicId, String CategoryId)
        {
            ViewBag.FAQs = context.FAQs.OrderBy(f => f.FAQName).ToList();
            var FAQ = context.FAQs.Include(c => c.Category).Include(t => t.Topic).Where(t => t.TopicId == TopicId).Where(c => c.CategoryId == CategoryId);
            return View(FAQ);
        }
        //topic action that accepts only TopicID
        [Route("/[controller]/index/topic/{TopicID?}")]
        public IActionResult topic(String TopicId) {
            ViewBag.FAQs = context.FAQs.OrderBy(f => f.FAQName).ToList();
               var FAQ = context.FAQs.Include(c => c.Category).Include(t => t.Topic).Where(t => t.TopicId == TopicId);
            return View(FAQ);
        }

        //category method that accept category id 
        [Route("/[controller]/index/[action]/{CategoryId?}")]
        public IActionResult category(String CategoryId)
        {
            ViewBag.FAQs = context.FAQs.OrderBy(f => f.FAQName).ToList();
            var FAQ = context.FAQs.Include(c => c.Category).Include(t => t.Topic).Where(c => c.CategoryId == CategoryId);
            return View(FAQ);
        }
        //category action that accepts categoryID and topic ID and filters the data using topicID
        [Route("/[controller]/index/[action]/{TopicID?}/category/{CategoryId?}")]
        public IActionResult category(String CategoryId, String TopicId)
        {
            ViewBag.FAQs = context.FAQs.OrderBy(f => f.FAQName).ToList();
            var FAQ = context.FAQs.Include(c => c.Category).Include(t => t.Topic).Where(c => c.CategoryId == CategoryId).Where(t => t.TopicId == TopicId);
            return View(FAQ);
        }
    }
}

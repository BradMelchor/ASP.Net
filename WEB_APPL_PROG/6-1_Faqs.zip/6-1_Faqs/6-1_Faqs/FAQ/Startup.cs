//Brad Melchor
//COP4813.0m1
//10.6.20
//FAQ
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using FAQ.Models;
using Microsoft.EntityFrameworkCore.Migrations.Operations;

namespace FAQ
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
            services.AddDbContext<FAQContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("FAQContext")));
            //creates lowercase urls with trailing slashes
            services.AddRouting(options =>
            {
                options.LowercaseUrls = true;
                options.AppendTrailingSlash = true;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            //maproutes to different urls if not overridden by actions
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                   name: "Categorys",
                  pattern: "{controller=Home}/index/topic/{TopicId?}/[action=categorys]/{CategoryId?}");

                endpoints.MapControllerRoute(
                   name: "Topics",
                  pattern: "{controller=Home}/index/{action=topic2}/{TopicId?}/category/{CategoryId?}");
                endpoints.MapControllerRoute(
                   name: "Category",
                  pattern: "{controller=Home}/index/{action=category}/{CategoryId?}");

                endpoints.MapControllerRoute(
                   name: "Topic",
                  pattern: "{controller=Home}/index/{action=topic}/{TopicId?}");
            

                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
        });
        
        }
    }
}

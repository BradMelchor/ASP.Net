﻿//Brad Melchor
//COP4813.0m1
//10.6.20
//FAQ
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FAQ.Models
{
    //gets and sets topicId and the name of it
    public class Topic
    {
        [Key]
        [StringLength(200)]
        public string TopicId { get; set; }

        public string Name { get; set; }
    }
}

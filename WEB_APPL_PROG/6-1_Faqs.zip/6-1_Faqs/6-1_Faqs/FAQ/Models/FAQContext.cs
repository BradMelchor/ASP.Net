﻿//Brad Melchor
//COP4813.0m1
//10.6.20
//FAQ
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FAQ.Models
{
    public class FAQContext : DbContext
    {
        public FAQContext(DbContextOptions<FAQContext> options)
            : base(options)
        { }
    
        //creates databases for FAQ, Category, and Topic
    public DbSet<FAQ> FAQs { get; set; }
    public DbSet<Category> Categories { get; set; }
    public DbSet<Topic> Topics { get; set; }
        //module builder uses to seed databases with initial data
    protected override void OnModelCreating(ModelBuilder modelBuilder) {
            //creates Category initial data
            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = "hist", Name = "History" },
                new Category { CategoryId = "gen", Name = "General" }
            );
            //creates Topic initial data
            modelBuilder.Entity<Topic>().HasData(
                new Topic { TopicId = "bstrap", Name = "BootStrap" },
                new Topic { TopicId = "c", Name = "C#" },
                new Topic { TopicId = "js", Name = "Javascript" }
            );
            //creates FAQ initial data
        modelBuilder.Entity<FAQ>().HasData(
                new FAQ { FAQId = 1,
                    FAQName="When was Bootstrap first released?",
                    Detail = "In 2011.", 
                    TopicId="bstrap",
                    CategoryId = "hist"
                },
                new FAQ
                {
                    FAQId = 2,
                    FAQName = "What is Bootstrap?",
                    Detail = "A CSS framework for creating responsive web apps for multiple screens.",
                    TopicId = "bstrap",
                    CategoryId = "gen"
                },
                new FAQ
                {
                    FAQId = 3,
                    FAQName = "What is C#?",
                    Detail = "A general purpose object oriented language that uses a concise, Java-like syntax",
                    TopicId = "c",
                    CategoryId = "gen"
                },
                new FAQ
                {
                    FAQId = 4,
                    FAQName = "When was C# first released?",
                    Detail = "In 2002.",
                    TopicId = "c",
                    CategoryId = "hist"
                },
                new FAQ
                {
                    FAQId = 5,
                    FAQName = "What is Javascript?",
                    Detail = "A general purpose scripting langage that executes in a browser.",
                    TopicId = "js",
                    CategoryId = "hist"
                }

            );
    }
}
}
﻿//Brad Melchor
//COP4813.0m1
//10.6.20
//FAQ
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FAQ.Models
{
    //gets and sets category id and the name of the category
    public class Category
    {
        public string CategoryId { get; set; }
        public string Name { get; set; }
    }
}

﻿//Brad Melchor
//COP4813.0m1
//11.4.2020
//10-1 TicTacToe
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
namespace _10_1_TicTacToe.Models
{
    public class TicTacToeViewModel
    {
        public TicTacToeViewModel()
        {
            CurrentGame = new TicTacToe();
        }
        public TicTacToeViewModel(ISession session)
        {
            this.session = session;
        }
        public string PlayerTurn { get; set; }
        public string Winner { get; set; }
        public string tL { get; set; }
        public string tM { get; set; }
        public string tR { get; set; }
        public string mL { get; set; }
        public string mM { get; set; }
        public string mR { get; set; }
        public string bL { get; set; }
        public string bM { get; set; }
        public string bR { get; set; }
        public TicTacToe CurrentGame { get; set; }
        private ISession session { get; set; }
        public string row { get; set; }

        public string column { get; set; }
    }
}

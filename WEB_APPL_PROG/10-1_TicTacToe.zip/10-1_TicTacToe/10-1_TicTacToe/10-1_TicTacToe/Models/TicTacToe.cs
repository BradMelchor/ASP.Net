﻿//Brad Melchor
//COP4813.0m1
//11.4.2020
//10-1 TicTacToe
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _10_1_TicTacToe.Models
{
    public class TicTacToe
    {
        public string PlayerTurn { get; set; }
        public string Winner { get; set; }
        public string tL { get; set; }
        public string tM { get; set; }
        public string tR { get; set; }
        public string mL { get; set; }
        public string mM { get; set; }
        public string mR { get; set; }
        public string bL { get; set; }
        public string bM { get; set; }
        public string bR { get; set; }

    }
}

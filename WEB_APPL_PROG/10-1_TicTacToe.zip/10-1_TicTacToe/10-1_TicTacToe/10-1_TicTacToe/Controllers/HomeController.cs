﻿//Brad Melchor
//COP4813.0m1
//11.4.2020
//10-1 TicTacToe
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using _10_1_TicTacToe.Models;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.ComponentModel.DataAnnotations.Schema;

namespace _10_1_TicTacToe.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index([FromForm]string row , [FromForm]string column, TicTacToeViewModel r)
        {
            var model = new TicTacToeViewModel(HttpContext.Session) {
                row = row,
                column = column
            };
            model.PlayerTurn = "X";


            if (model.PlayerTurn == "X")
            {
                if (row == "top")
                {
                    if (column == "left")
                    {
                        
                        return RedirectToAction("index", model);

                    }
                    else if (column == "middle")
                    {
                        TempData[nameof(model.tM)] = "X";
                        return View("index", model);
                    }
                    else
                    {
                        TempData[nameof(model.tR)] = "X";
                        return View("index", model);
                    }
                }
                else if (row == "middle")
                {
                    if (column == "left")
                    {
                        TempData[nameof(model.mL)] = "X";
                        return View("index", model);
                    }
                    else if (column == "middle")
                    {
                        TempData[nameof(model.mM)] = "X";
                        return View("index", model);
                    }
                    else
                    {
                        TempData[nameof(model.mR)] = "X";
                        return View("index", model);
                    }
                }
                else {
                    if (column == "left")
                    {
                        TempData[nameof(model.bL)] = "X";
                        return View("index", model);
                    }
                    else if (column == "middle")
                    {
                        TempData[nameof(model.bM)] = "X";
                        return View("index", model);
                    }
                    else
                    {
                        TempData[nameof(model.bR)] = "X";
                        return View("index", model);
                    }
                }
                
            }
            else if (model.PlayerTurn == "O")
            {
                if (row == "top")
                {
                    if (column == "left")
                    {
                        TempData[nameof(model.tL)] = "O";
                        return View("index", model);

                    }
                    else if (column == "middle")
                    {
                        TempData[nameof(model.tM)] = "O";
                        return View("index", model);
                    }
                    else
                    {
                        TempData[nameof(model.tR)] = "O";
                        return View("index", model);
                    }
                }
                else if (row == "middle")
                {
                    if (column == "left")
                    {
                        TempData[nameof(model.mL)] = "O";
                        return View("index", model);
                    }
                    else if (column == "middle")
                    {
                        TempData[nameof(model.mM)] = "O";
                        return View("index", model);
                    }
                    else
                    {
                        TempData[nameof(model.mR)] = "O";
                        return View("index", model);
                    }
                }
                else
                {
                    if (column == "left")
                    {
                        TempData[nameof(model.bL)] = "O";
                        return View("index", model);
                    }
                    else if (column == "middle")
                    {
                        TempData[nameof(model.bM)] = "O";
                        return View("index", model);
                    }
                    else
                    {
                        TempData[nameof(model.bR)] = "O";
                        return View("index", model);
                    }
                }

            }
            return View(model);


        }

        [HttpPost]
        public IActionResult Index(TicTacToeViewModel model)
        {
            TempData[nameof(model.tL)] = model.tL;
            TempData[nameof(model.tM)] = model.tM;
            TempData[nameof(model.tR)] = model.tR;
            TempData[nameof(model.mL)] = model.mL;
            TempData[nameof(model.mM)] = model.mM;
            TempData[nameof(model.mR)] = model.mR;
            TempData[nameof(model.bL)] = model.bL;
            TempData[nameof(model.bM)] = model.bM;
            TempData[nameof(model.bR)] = model.bR;
            TempData[nameof(model.PlayerTurn)] = model.PlayerTurn;
            if (model.Winner != null) {
                TempData["message"] = model.PlayerTurn + " is the winner!";
            }

            if (model.PlayerTurn == "X")
            {
                
                model.PlayerTurn = "O";
                return View("index",model) ;
            }
            else if (model.PlayerTurn == "O")
            {
                model.PlayerTurn = "X";
                return View("index", model);
            }
            return View("index", model);
        }
    }
}

﻿//Brad Melchor
//COP4813.0m1
//10.21.2020
//8-1 Trips
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TripLog.Models;

namespace TripLog.Controllers
{
    public class TripController : Controller
    {
        private TripContext context { get; set; }

        public TripController(TripContext ctx)
        {
            context = ctx;
        }
        public IActionResult Index()
        {
            TempData.Clear();
            return View();
        }
        [Route("/[controller]/[action]/Page1")]
        [HttpGet]
        public IActionResult Add()
        {

            return View("Page1", new Trip());
        }
        //calls second page and stores into temp Data
        [Route("/[controller]/Add/Page2")]
        [HttpPost]
        public IActionResult Add(Trip trip)
        {
            TempData["Destination"] = trip.Destination;
            TempData["UserMessage1"] = " Add info for " + trip.Accommodation;
            TempData["StartDate"] = trip.StartDate;
            TempData["EndDate"] = trip.EndDate;
            TempData["Accommodation"] = trip.Accommodation;
            return RedirectToAction("Next", "Trip");

        }
        //first button 
        public IActionResult Next(Trip trip)
        {
            TempData["Destination"] = trip.Destination;
            TempData["UserMessage1"] = " Add info for " + trip.Accommodation;
            TempData["StartDate"] = trip.StartDate;
            TempData["EndDate"] = trip.EndDate;
            TempData["Accommodation"] = trip.Accommodation;
            return View("Page2", trip);
        }
        //second button
        [Route("/[controller]/Add/Page3")]
        public IActionResult Next2(Trip trip)
        {

            TempData["UserMessage2"] = trip.Destination;
            TempData["AccommodationPhone"] = trip.AccommodationPhone;
            TempData["AccommodationEmail"] = trip.AccommodationEmail;
            return View("Page3", trip);

        }
        //method that saves the trip changes to the database
        public IActionResult Save(Trip trip)
        {
            context.Trips.Add(trip);
            context.SaveChanges();
            TempData["Message"] = trip.Destination + " has been Added.";
            return RedirectToAction("Index", "Home");
        }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TripLog.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Trips",
                columns: table => new
                {
                    TripID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Destination = table.Column<string>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                    Accommodation = table.Column<string>(nullable: true),
                    AccommodationPhone = table.Column<string>(nullable: true),
                    AccommodationEmail = table.Column<string>(nullable: true),
                    Thingtodo1 = table.Column<string>(nullable: true),
                    Thingtodo2 = table.Column<string>(nullable: true),
                    Thingtodo3 = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Trips", x => x.TripID);
                });

            migrationBuilder.InsertData(
                table: "Trips",
                columns: new[] { "TripID", "Accommodation", "AccommodationEmail", "AccommodationPhone", "Destination", "EndDate", "StartDate", "Thingtodo1", "Thingtodo2", "Thingtodo3" },
                values: new object[] { 1, "Twin Peaks", "twinpeaKs@twinpeaks.com", "123-456-789", "Orlando", new DateTime(2020, 10, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2020, 10, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Eat", "Theme Parks", "Go to a botanical Garden" });

            migrationBuilder.InsertData(
                table: "Trips",
                columns: new[] { "TripID", "Accommodation", "AccommodationEmail", "AccommodationPhone", "Destination", "EndDate", "StartDate", "Thingtodo1", "Thingtodo2", "Thingtodo3" },
                values: new object[] { 2, "", "", "", "Gainesville", new DateTime(2020, 10, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2020, 10, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "drive around city", "see Gator stadium", "Watch movies" });

            migrationBuilder.InsertData(
                table: "Trips",
                columns: new[] { "TripID", "Accommodation", "AccommodationEmail", "AccommodationPhone", "Destination", "EndDate", "StartDate", "Thingtodo1", "Thingtodo2", "Thingtodo3" },
                values: new object[] { 3, "", "", "", "Daytona Beach", new DateTime(2020, 10, 6, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2020, 10, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "", "" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Trips");
        }
    }
}

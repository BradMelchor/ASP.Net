﻿//Brad Melchor
//COP4813.0m1
//10.21.2020
//8-1 Trips
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TripLog.Models
{
    public class Trip
    {
        public int TripID { get; set;}

        [Required(ErrorMessage = "Please enter a Destination")]
        public string Destination { get; set; }

        [Required(ErrorMessage ="Please enter a start date")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "Please enter a end date")]
        public DateTime EndDate { get; set; }

        public string Accommodation { get; set; }
        public string AccommodationPhone { get; set; }
        public string AccommodationEmail { get; set; }
        public string Thingtodo1 { get; set; }
        public string Thingtodo2 { get; set; }
        public string Thingtodo3 { get; set; }


    }
}

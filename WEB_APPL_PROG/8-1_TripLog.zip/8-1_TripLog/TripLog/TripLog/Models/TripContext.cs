﻿//Brad Melchor
//COP4813.0m1
//10.21.2020
//8-1 Trips
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
//makes a database connection for trips, then seeds initial data
namespace TripLog.Models
{
    public class TripContext :DbContext
    {
        public TripContext(DbContextOptions<TripContext> options)
            : base(options)
        {}

        public DbSet<Trip> Trips { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Trip>().HasData(
                new Trip
                {
                    TripID = 1,
                    Destination = "Orlando",
                    StartDate = new DateTime(2020, 10, 1),
                    EndDate = new DateTime(2020, 10, 2),
                    Accommodation = "Twin Peaks",
                    AccommodationEmail = "twinpeaKs@twinpeaks.com",
                    AccommodationPhone = "123-456-789",
                    Thingtodo1 = "Eat",
                    Thingtodo2 = "Theme Parks",
                    Thingtodo3 = "Go to a botanical Garden"
                },
                new Trip
                {
                    TripID = 2,
                    Destination = "Gainesville",
                    StartDate = new DateTime(2020, 10, 3),
                    EndDate = new DateTime(2020, 10, 4),
                    Accommodation = "",
                    AccommodationEmail = "",
                    AccommodationPhone = "",
                    Thingtodo1 = "drive around city",
                    Thingtodo2 = "see Gator stadium",
                    Thingtodo3 = "Watch movies"
                },

                new Trip
                {
                    TripID = 3,
                    Destination = "Daytona Beach",
                    StartDate = new DateTime(2020, 10, 5),
                    EndDate = new DateTime(2020, 10, 6),
                    Accommodation = "",
                    AccommodationEmail = "",
                    AccommodationPhone = "",
                    Thingtodo1 = "",
                    Thingtodo2 = "",
                    Thingtodo3 = ""
                }
            ); ;
        }
    }
}

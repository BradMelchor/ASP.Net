﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace QuarterlySales.Models
{
    public class SalesGridBuilder : GridBuilder
    {
        // this constructor gets current route data from session
        public SalesGridBuilder(ISession sess) : base(sess) { }

        // this constructor stores filtering route segments, as well as
        // the paging and sorting route segments stored by the base constructor
        public SalesGridBuilder(ISession sess, EmployeeGridDTO values,
            string defaultSortField) : base(sess, values, defaultSortField)
        {
            // store filter route segments - add filter prefixes if this is initial load
            // of page with default values rather than route values (route values have pref
            routes.EmployeeIdFilter =  values.EmployeeId;
            routes.YearFilter = values.Year;
            routes.QuarterFilter = values.Quarter;

            SaveRouteSegments();
        }

        // load new filter route segments contained in a string array - add filter prefix 
        // to each one. if filtering by author (rather than just 'all'), add author slug 
        public void LoadFilterSegments(string[] filter, Employee employee)
        {
            if (employee == null)
            {
                routes.EmployeeIdFilter =  filter[0];
            }
            else
            {
                routes.EmployeeIdFilter = filter[0]
                    + "-" + employee.Fullname.Slug();
            }
            routes.YearFilter = filter[1];
            routes.QuarterFilter = filter[2];
        }
        public void ClearFilterSegments() => routes.ClearFilters();

        //~~ filter flags ~~//
        string def = EmployeeGridDTO.DefaultFilter;   // get default filter value from static DTO property
        public bool IsFilterByEmployeeId => routes.EmployeeIdFilter != def;
        public bool IsFilterByYear => routes.YearFilter != def;
        public bool IsFilterByQuarter => routes.QuarterFilter != def;

        //~~ sort flags ~~//
        public bool IsSortByYear =>
            routes.SortField.EqualsNoCase(nameof(Sales.Year));
        public bool IsSortByQuarter =>
            routes.SortField.EqualsNoCase(nameof(Sales.Quarter));
    
}
}

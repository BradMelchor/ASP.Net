﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace QuarterlySales.Models
{
    internal class SeedEmployees : IEntityTypeConfiguration<Employee>
    {
        public void Configure(EntityTypeBuilder<Employee> entity)
        {
            entity.HasData(new Employee
            {
                EmployeeId = 1,
                Firstname = "Ada",
                Lastname = "Lovelace",
                DOB = new DateTime(1956, 12, 10),
                DateOfHire = new DateTime(1995, 1, 1),
                ManagerId = 0  // has no manager
            },
                new Employee
                {
                    EmployeeId = 2,
                    Firstname = "Katherine",
                    Lastname = "Johnson",
                    DOB = new DateTime(1966, 8, 26),
                    DateOfHire = new DateTime(1999, 1, 1),
                    ManagerId = 1
                },
                new Employee
                {
                    EmployeeId = 3,
                    Firstname = "Grace",
                    Lastname = "Hopper",
                    DOB = new DateTime(1975, 12, 9),
                    DateOfHire = new DateTime(1999, 1, 1),
                    ManagerId = 1
                }
            );
        }
    }
}
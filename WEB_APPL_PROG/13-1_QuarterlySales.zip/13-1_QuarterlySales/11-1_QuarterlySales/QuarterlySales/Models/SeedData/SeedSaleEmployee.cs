﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace QuarterlySales.Models
{
    internal class SeedSaleEmployees : IEntityTypeConfiguration<SaleEmployee>
    {
        public void Configure(EntityTypeBuilder<SaleEmployee> entity)
        {
            entity.HasData(
                new SaleEmployee { EmployeeId = 2, SalesId = 1 },
                new SaleEmployee { EmployeeId = 2, SalesId = 2 },
                new SaleEmployee { EmployeeId = 3, SalesId = 3 },
                new SaleEmployee { EmployeeId = 3, SalesId = 4 }
                
            );
        }
    }
}

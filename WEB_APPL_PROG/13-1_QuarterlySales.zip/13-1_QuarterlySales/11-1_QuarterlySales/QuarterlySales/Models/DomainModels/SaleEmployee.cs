﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuarterlySales.Models
{
    public class SaleEmployee
    {
        
        public int SalesId { get; set; }
        public int EmployeeId { get; set; }

        // navigation properties
        public Employee Employee { get; set; }
        public Sales sales { get; set; }
    }
}

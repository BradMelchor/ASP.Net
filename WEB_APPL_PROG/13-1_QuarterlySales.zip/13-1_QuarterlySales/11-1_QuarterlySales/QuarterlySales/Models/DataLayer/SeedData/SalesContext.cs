﻿using System;
using Microsoft.EntityFrameworkCore;

namespace QuarterlySales.Models
{
    public class SalesContext : DbContext
    {
        public SalesContext(DbContextOptions<SalesContext> options)
            : base(options)
        { }

        public DbSet<Sales> Sales { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<SaleEmployee> SaleEmployee { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SaleEmployee>().HasKey(ba => new { ba.SalesId, ba.EmployeeId });
            modelBuilder.Entity<SaleEmployee>().HasOne(ba => ba.sales)
                .WithMany(b => b.SaleEmployees)
                .HasForeignKey(ba => ba.SalesId);
            modelBuilder.Entity<SaleEmployee>().HasOne(ba => ba.Employee)
                .WithMany(a => a.SaleEmployees)
                .HasForeignKey(ba => ba.EmployeeId);
     
        }

    }
}

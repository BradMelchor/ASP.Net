﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Linq.Expressions;

namespace QuarterlySales.Models
{
    public class SalesOptions : QueryOptions<Sales>
    {
        public void SortFilter(SalesGridBuilder builder)
        {
            // filter
            if (builder.IsFilterByEmployeeId)
            {
                Where = b => b.EmployeeId == builder.CurrentRoute.EmployeeIdFilter.ToInt();
            }
            if (builder.IsFilterByYear)
            {
                Where = y => y.Year == builder.CurrentRoute.YearFilter.ToInt();
            }
            if (builder.IsFilterByEmployeeId)
            {
                int id = builder.CurrentRoute.EmployeeIdFilter.ToInt();
                if (id > 0)
                    // to filter the books by author, use the LINQ Any() method. 
                    Where = b => b.SaleEmployees.Any(ba => ba.EmployeeId== id);
            }

            // sort 
            if (builder.IsSortByYear)
            {
                OrderBy = b => b.Year;
            }
            else if (builder.IsSortByQuarter)
            {
                OrderBy = b => b.Quarter;
            }
            else
            {
                OrderBy = b => b.EmployeeId;
            }
        }
    }
}

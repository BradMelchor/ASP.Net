﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuarterlySales.Models
{
    public interface ISalesUnitOfWork
    {
        Repository<Sales> Sales { get; }
        Repository<Employee> Employees { get; }

        void DeleteCurrentSaleEmployee(Sales sales);
        void AddNewSaleEmployee(Sales sales, int[] Employeeids);
        void Save();
    }
}

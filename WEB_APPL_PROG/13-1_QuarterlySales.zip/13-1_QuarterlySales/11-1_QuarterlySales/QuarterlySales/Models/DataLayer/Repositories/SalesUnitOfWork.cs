﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuarterlySales.Models
{
    public class SalesUnitOfWork : ISalesUnitOfWork
    {
        private SalesContext context { get; set; }
        public SalesUnitOfWork(SalesContext ctx) => context = ctx;

        private Repository<Sales> SalesData;
        public Repository<Sales> Sales
        {
            get
            {
                if (SalesData == null)
                    SalesData = new Repository<Sales>(context);
                return SalesData;
            }
        }

        private Repository<Employee> EmployeeData;
        public Repository<Employee> Employees
        {
            get
            {
                if (EmployeeData == null)
                    EmployeeData = new Repository<Employee>(context);
                return EmployeeData;
            }
        }

        private Repository<SaleEmployee> SaleEmployeeData;
        public Repository<SaleEmployee> SaleEmployees
        {
            get
            {
                if (SaleEmployeeData == null)
                    SaleEmployeeData = new Repository<SaleEmployee>(context);
                return SaleEmployeeData;
            }
        }

        
        public void DeleteCurrentSaleEmployee(Sales sales)
        {
            var currentEmployee = SaleEmployees.List(new QueryOptions<SaleEmployee>
            {
                Where = ba => ba.SalesId == sales.SalesId
            });
            foreach (SaleEmployee ba in currentEmployee)
            {
                SaleEmployees.Delete(ba);
            }
        }

        public void AddNewSaleEmployee(Sales sales, int[] authorids)
        {
            foreach (int id in authorids)
            {
                SaleEmployee ba =
                    new SaleEmployee { SalesId = sales.SalesId, EmployeeId = id };
                SaleEmployees.Insert(ba);
            }
        }

        public void Save() => context.SaveChanges();
    }
}

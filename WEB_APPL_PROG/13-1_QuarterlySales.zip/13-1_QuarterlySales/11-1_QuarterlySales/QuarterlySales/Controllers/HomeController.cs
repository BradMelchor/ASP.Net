﻿using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuarterlySales.Models;
using System;

namespace QuarterlySales.Controllers
{
    public class HomeController : Controller
    {
        private SalesUnitOfWork data { get; set; }
        public HomeController(SalesContext ctx) => data = new SalesUnitOfWork(ctx);

        [HttpGet]
        public ViewResult Index(EmployeeGridDTO values)
        {
            var builder = new SalesGridBuilder(HttpContext.Session, values,
                defaultSortField: nameof(Sales.EmployeeId));

            var options = new SalesOptions
            {
                
                OrderByDirection = builder.CurrentRoute.SortDirection,
                PageNumber = builder.CurrentRoute.PageNumber,
                PageSize = builder.CurrentRoute.PageSize
            };
            options.SortFilter(builder);

            var vm = new SalesListViewModel {
                Sales = data.Sales.List(options),  // execute sales query
                Employees = data.Employees.List(new QueryOptions<Employee> { OrderBy = e => e.Firstname }),
                CurrentRoute = builder.CurrentRoute,
                TotalPages = builder.GetTotalPages(data.Sales.Count)
            };
            return View(vm);
        }

        [HttpPost]
        public RedirectToActionResult Index(Employee employee) {
            if (employee.EmployeeId > 0)
                return RedirectToAction("Index", new { id = employee.EmployeeId });
            else
                // pass empty string for id segment to clear any previous values
                return RedirectToAction("Index", new { id = "" });
        }
        [HttpPost]
        public RedirectToActionResult Filter(string[] filter, bool clear = false)
        {
            // get current route segments from session
            var builder = new SalesGridBuilder(HttpContext.Session);

            // clear or update filter route segment values. If update, get author data
            // from database so can add author name slug to author filter value.
            if (clear)
            {
                builder.ClearFilterSegments();
            }
            else
            {
                var author = data.Employees.Get(filter[0].ToInt());
                builder.CurrentRoute.PageNumber = 1;
                builder.LoadFilterSegments(filter, author);
            }

            // save route data back to session and redirect to Book/List action method,
            // passing dictionary of route segment values to build URL
            builder.SaveRouteSegments();
            return RedirectToAction("List", builder.CurrentRoute);
        }

        [HttpPost]
        public RedirectToActionResult PageSize(int pagesize)
        {
            var builder = new SalesGridBuilder(HttpContext.Session);

            builder.CurrentRoute.PageSize = pagesize;
            builder.SaveRouteSegments();

            return RedirectToAction("List", builder.CurrentRoute);
        }

    }
}

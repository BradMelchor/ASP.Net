﻿//Brad Melchor
//COP4813.0m1
//9.22.20
//Contact Manager
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using ContactManager.Models;

namespace ContactManager.Controllers
{
    public class ContactController : Controller
    {
        private ContactsContext context { get; set; }

        public ContactController(ContactsContext ctx) {
            context = ctx;
        }
        //creates Add method, returns edit view with a new contact method
        [HttpGet]
        public IActionResult Add() {
            ViewBag.Action = "Add";
            ViewBag.Categories = context.Categories.OrderBy(g => g.Name).ToList();
            return View("Edit", new Contact());
        }
        //creates edit get method, passes contactID to be edited
        [HttpGet]
        public IActionResult Edit(int id) {
            ViewBag.Action = "Edit";
            ViewBag.Categories = context.Categories.OrderBy(g => g.Name).ToList();
            var Contact = context.Contacts.Find(id);
            return View(Contact);
        }
        //creates the get method for Details, passes contactID
        [HttpGet]
        public IActionResult Details(int id)
        {
            ViewBag.Action = "Details";
            var contact = context.Contacts.Find(id);
            return View(contact);
        }
        //Edit post method,checks the validation of input before calling methods.
        [HttpPost]
        public IActionResult Edit(Contact Contact) {
            if (ModelState.IsValid) {
                if (Contact.ContactId == 0) 
                    context.Contacts.Add(Contact); // if contactID = 0 then calls ADD method
                else
                    context.Contacts.Update(Contact); //if contactID is not 0 it updates the contact
                context.SaveChanges();
                return RedirectToAction("Index", "Home"); //saves updated info and returns to index page
            } else {
                ViewBag.Action = (Contact.ContactId == 0) ? "Add": "Edit"; //if not valid it returns to the add or edit page
                ViewBag.Categories = context.Categories.OrderBy(g => g.Name).ToList();
                return View(Contact);
            }
        }
        //creates delete get method, passes ID.
        [HttpGet]
        public IActionResult Delete(int id) {
            var contact = context.Contacts.Find(id);
            return View(contact);
        }
        //takes the contact id and removes the contact, saves it and return home.
        [HttpPost]
        public IActionResult Delete(Contact Contact) { 
            context.Contacts.Remove(Contact);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }
    }
}
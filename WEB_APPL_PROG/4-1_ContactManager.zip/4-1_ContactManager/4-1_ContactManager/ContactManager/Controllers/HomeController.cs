﻿//Brad Melchor
//COP4813.0m1
//9.22.20
//Contact Manager
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ContactManager.Models;
using Microsoft.EntityFrameworkCore;

namespace ContactManager.Controllers
{
    public class HomeController : Controller
    {
        private ContactsContext context { get; set; }
        public HomeController(ContactsContext ctx)
        {
            context = ctx;
        }
        //creates the index method which returns home and shows the contacts in the database.
        public IActionResult Index()
        {
            var contacts = context.Contacts.Include(m => m.Category).OrderBy(m => m.LName).ToList();
            return View(contacts);
        }
    }
}

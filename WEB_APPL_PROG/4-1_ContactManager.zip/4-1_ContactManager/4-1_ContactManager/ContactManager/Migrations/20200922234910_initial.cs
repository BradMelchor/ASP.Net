﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ContactManager.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "ContactId",
                keyValue: 1,
                column: "Date",
                value: new DateTime(2020, 9, 22, 19, 49, 10, 68, DateTimeKind.Local).AddTicks(5980));

            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "ContactId",
                keyValue: 2,
                column: "Date",
                value: new DateTime(2020, 9, 22, 19, 49, 10, 71, DateTimeKind.Local).AddTicks(1999));

            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "ContactId",
                keyValue: 3,
                column: "Date",
                value: new DateTime(2020, 9, 22, 19, 49, 10, 71, DateTimeKind.Local).AddTicks(2047));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "ContactId",
                keyValue: 1,
                column: "Date",
                value: new DateTime(2020, 9, 22, 19, 34, 6, 994, DateTimeKind.Local).AddTicks(642));

            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "ContactId",
                keyValue: 2,
                column: "Date",
                value: new DateTime(2020, 9, 22, 19, 34, 6, 996, DateTimeKind.Local).AddTicks(6467));

            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "ContactId",
                keyValue: 3,
                column: "Date",
                value: new DateTime(2020, 9, 22, 19, 34, 6, 996, DateTimeKind.Local).AddTicks(6512));
        }
    }
}

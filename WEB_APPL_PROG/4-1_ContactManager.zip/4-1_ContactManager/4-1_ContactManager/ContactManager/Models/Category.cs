﻿//Brad Melchor
//COP4813.0m1
//9.22.20
//Contact Manager
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace ContactManager.Models
{
    public class Category
    {
        //creates the get and set methods for CategoryID and Name.
        public string CategoryId { get; set; }
        public string Name { get; set; }
    }
}

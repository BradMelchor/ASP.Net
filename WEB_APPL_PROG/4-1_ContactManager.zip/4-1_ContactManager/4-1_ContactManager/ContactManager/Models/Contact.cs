﻿//Brad Melchor
//COP4813.0m1
//9.22.20
//Contact Manager
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography.X509Certificates;

namespace ContactManager.Models
{
    public class Contact
    {
        //EF Core will configure the database to generate this value\
        //Makes range of ContactID start at 0
        [Range (0 , 1000, ErrorMessage ="Please Enter a Contact ID greater than 0")]
        public int ContactId { get; set; }
        
        [Required(ErrorMessage = "Please enter a First name.")]
        public string FName { get; set; }

        [Required(ErrorMessage = "Please enter a Last name.")]
        public string LName { get; set; }
        [Required(ErrorMessage = "Please enter a Phone Number.")]
        public string Phone { get; set; }
        [Required(ErrorMessage = "Please enter an Email Address.")]
        public string Email { get; set; }

        public string Organization { get; set; }

        [Required(ErrorMessage = "Please enter a Category.")]
        public string CategoryId { get; set; }
        public Category Category { get; set; }
        public DateTime Date { get; set; }
        //makes Slug that changes URL to first name and last name.

        public string Slug => FName?.Replace(' ', '-').ToLower() + '-' + LName?.ToString();
    }
}

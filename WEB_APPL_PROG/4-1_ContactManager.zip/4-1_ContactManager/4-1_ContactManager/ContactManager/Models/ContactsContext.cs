﻿//Brad Melchor
//COP4813.0m1
//9.22.20
//Contact Manager
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ContactManager.Models
{
    public class ContactsContext : DbContext //creates a link to database
    {
        public ContactsContext(DbContextOptions<ContactsContext> options)
            : base(options)
        { }

        public DbSet<Contact> Contacts { get; set; } //method that allows database to set and get information
        public DbSet<Category> Categories { get; set; }//method that allows database to set and get categories

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {//creates db with category content 
            modelBuilder.Entity<Category>().HasData(
                 new Category { CategoryId = "A", Name = "Friend" },
                 new Category { CategoryId = "B", Name = "work" },
                 new Category { CategoryId = "C", Name = "Family" }
             );
            //seeds database with initial contact information
            modelBuilder.Entity<Contact>().HasData(
                new Contact
                {
                    ContactId = 1,
                    FName = "Delores",
                    LName = "Del Rio",
                    Phone = "555-987-6543",
                    Email = "delores@hotmail.com",
                    Organization = "",
                    CategoryId = "A",
                    Date = DateTime.Today


                },
                new Contact
                {
                    ContactId = 2,
                    FName = "Efren",
                    LName = "Herrera",
                    Phone = "555-456-7890",
                    Email = "efren@aol.com",
                    Organization = "",
                    CategoryId = "B",
                    Date = DateTime.Today

                },
                new Contact
                {
                    ContactId = 3,
                    FName = "Mary Ellen",
                    LName = "Walton",
                    Phone = "555-123-4567",
                    Email = "MaryEllen@yahoo.com",
                    Organization = "",
                    CategoryId = "C",
                    Date = DateTime.Today
                }) ;
        }
    }
}

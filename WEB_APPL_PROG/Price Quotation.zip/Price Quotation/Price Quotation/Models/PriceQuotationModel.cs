﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Price_Quotation.Models
{
    public class PriceQuotationModel
    {
        [Required(ErrorMessage = "Please enter a Subtotal.")]
        [Range(1, 99999, ErrorMessage = "Monthly investment amount must be between 1 and 99,999.")]
        public decimal? Subtotal { get; set; }
        [Required(ErrorMessage = "Please enter a Discount Percent.")]
        [Range(1, 100, ErrorMessage = 
            "Discount Percent must be between 0 and 100.")]
        public decimal? DiscountPercent { get; set; }
        public decimal? CalculateDiscount() {
            decimal? Discount = (DiscountPercent / 100);
            decimal? DiscountTotal = 0;

            DiscountTotal = (Subtotal * Discount);
            return DiscountTotal;
        }
        public decimal? CalculateDiscountsubtotal()
        {
            decimal? Discount = (DiscountPercent / 100);
            decimal? DiscountTotal = 0;
            decimal? Discountsaved = 0;
            DiscountTotal = (Subtotal * Discount);
            Discountsaved = (Subtotal - DiscountTotal);

            return Discountsaved;
        }

    }
}

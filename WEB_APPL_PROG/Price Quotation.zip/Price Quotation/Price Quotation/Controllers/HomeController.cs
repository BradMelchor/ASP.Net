﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Price_Quotation.Models;
using Microsoft.AspNetCore.Mvc;

namespace Price_Quotation.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.DV = 0;
            ViewBag.SV = 0;
            return View();
        }
        [HttpPost]
        public IActionResult Index(PriceQuotationModel model) {
            if (ModelState.IsValid)
            {
                ViewBag.DV = model.CalculateDiscount();
                ViewBag.SV = model.CalculateDiscountsubtotal();
            }
            else {
                ViewBag.DV = 0;
                ViewBag.SV = 0;
            }
            return View(model);
        }
    }
}
